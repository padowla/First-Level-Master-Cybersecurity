Teoria

**08/09/2023**

![f2d3b996b121c308150251de9513669e.png](:/e6a0cd5c2b754dffa65fa0b2f6e63dc9)
![411a126efc358ce0b5578bf054d95d1f.png](:/40331d64c2f546df99f47ca52f3e1c64)

# La rete e il Domain Name System
![6d713cff50abd43c591c1cb4678a8cd8.png](:/c3f1c9a87303411fab351789b86666c5)
![47445cfe490f4724020c71222b4bf4df.png](:/0c0fa752e4af4a2da9b34c2be8ee16e3)
![bf112541627a3574b3d57b4c85c8eec8.png](:/24a573184adf4981985fa8212784eee2)
![35763e0047db94cd7f1a7df3646cbfbd.png](:/6fc278b28b844cd49a983694f02956a9)
![20c4fd5ef924eaf5a0ccf52c356f4ff5.png](:/0ac2ce2287cb4b0eb6c3dd93adacab47)
![face7db18cc92c415097cbce4ff4f5bb.png](:/86401d4543e64a379009c25416cb434f)
![15d7d99d5399a5b8a1c1d2dd5a213ad9.png](:/6890cd36a4ff400bb5288afd046a081b)
![f9ce2b3f5d508ddabb3d15d0e8449031.png](:/12c93674e53c4699ae6db43cd63a68da)
![90452c6aea8273f37ce8b97e3d85800d.png](:/be6341f2956645ba80e593635cda192f)
![3ceb0a7772b44c1aa04b8ca35994b323.png](:/0a09cdd10a07454688404c30f7368769)
![e3eb5ef5fc3dd77231d0242c76835f4c.png](:/580e4a1498a0420a8017768dd88f4490)
![39dfeb7710c34bedc7335eff3a74e2cf.png](:/5c97a2dd608d4a46b62dc077e9f45430)
![bb0c3bf51ff60f69bfde4f21e860dcd2.png](:/09b1882acf2f4da292b4a7902a03bd80)
![9dc6c46e9962d10949803fbb13b93ef9.png](:/b6b49aa30c204aa8b627ad4700de3810)
![de5b32eae2d728d1822c0551dccb458f.png](:/b33cbde56d2f49a78ca70b83772e3600)
## Record SOA
![0feec3dc61113c5582fb29c6f8d0452d.png](:/f492a31c1b2048568f17f8e15b893823)
La chiocciola all'inizio indica il dominio trattato.
## Record NS
![8d02f6bc2e77dd779a4f5e32e0fb43e6.png](:/8d6f96d796a24a6da0012a1fd4a21491)

Esempio di delega:
![f6b88a2e1ab0461a19d3783374dc5172.png](:/1776af1e7d244c3bb7b135f496541377)

![7047b89ae496921320e7934aed33d8cd.png](:/8d0392f651494bbdab9ab6fa53429adc)
![69f8002efae9c565dba2a273fb1e045e.png](:/9a5f75ec747e41029e9ebd5e2e9735a5)

![60af53c4693c8755510272598aa85775.png](:/1316b9ab78da4e7aa2fc3e16a8109090)
![d50a24e81e620ee72f01d7a851b5d590.png](:/7a3f07586b3048e0aa06bdb05266c7c0)
![9c6ad8da63c073a2f36f66a1c1740800.png](:/ae39680a6d4046eea7023a92380d96d7)

## Cache poisoning
![ce6d00a540b8767191c8edcfe27e4ef1.png](:/a49356abb967450f900ec38c1909ef78)
![d3f460e8c6abff0631559c060e5b8a33.png](:/044cf3472d1a42b9923d96894c5edaeb)
Provando ad iniettare diversi messaggi di risposta DNS con Query ID crescenti.
![d958ebce2e911b097531c956e6d860c2.png](:/61bdb7eb28c745bfa56d4c9628396540)

# DNSSEC
![27ab377fcb81e22b8ebbbce85da35d49.png](:/1d3037d51c454678a788f3f289631ae1)
![cff0bae1a693eaf4b27d3da259a70cf1.png](:/0b4a06a49fb14912afe45473d43065eb)

**09/09/2023**
# Packet-Less Monitoring
![e83aa4e507f357162ec98813d9981614.png](:/453112a9272447ec9a678a08181351d2)
![7a0db752dd88223042d095900bb9dfb5.png](:/15cc0df8c7c148f4aa44ad9396a58f44)
![418e78bd5b1c5ce37a0f0a5528fbfbe1.png](:/a04f8aeb3eae4a4c9a80bff36f5cb0a0)
![48f716012edb1a24ef7c67dda93487f1.png](:/f44485b4eef6428a87e31f2690c72b3b)

**15/09/2023**
# DNSSEC
![44faec837cd1aca0fddead9272dba9b5.png](:/7d88f1e155ee4b62a39b18e4329067ef)
![2be62b3adbe016c57672ad61ee2b1aba.png](:/bdc3237e5bb4461ab3f9685842d23653)
![c0b403bfe234eb2917b88c896c770ddb.png](:/f491ad15354a4cf8a8dd38b776c002ac)
La trasmissione dei record avviene in chiaro dunque non protegge dalla confidenzialità dei dati.
![dd000a65847c36d277e4cb741d16a791.png](:/7e1a10152e0c4446b422896cd5641067)
E' stata introdotta parallelamente all'introduzione del DNSSEC il supporto all'EDNS.
Il protocollo DNS usa 2 protocolli per la trasmissione dei dati: TCP e UDP. UDP viene usato nell'interazione client-server
mentre il TCP viene usato nell'interazione tra nameserver primario e secondario. Ovvero quando il secondario si connette al primario e fa la verifica del timestamp della zona e vede che è più aggiornato, usa il TCP per fare il trasferimento della zona in quanto ci sono molti più dati da dover trasferire.
![e8d7494affad1358a18b86bedd7ed686.png](:/4e1d72e2e5474adab65c7f392958cb8a)
La dimensione massima di UDP può essere espansa fino a un valore di 1232
![d47502c45a2f2c1cf829abf8406ce004.png](:/e4076db94cef4d3384d2b9dc9c11839f)
![e4eaf059b66c770d0554432f675c5b77.png](:/eeac79a8490547a4923df78286ba5164)

# TSIG
![dba006b7f3f31ccc736bb33b5f48496b.png](:/a30c83a5fa7d412db7636daa082d12f4)
![12a5be04d99d75f2360cc406b87cfbd7.png](:/0bd77088bea44deebf2a159780d9c410)
Funzionamento del TSIG nel caso di trasferimento di zona dal primario al secondario:
![c22b5843c6139ae9a2de87d42d0fc373.png](:/d95738719fa5436090cd1c0f4d623e36)
Lo slave fa un query al master di tipo AXFR (trasferimento di zona). Il master fa il controllo della firma e del timestamp (dunque necessario utilizzo del protocollo NTP per master e slave).
![8327dad4d93d7b9cee5238a4b5941830.png](:/60ea368f3ffc42998942c0655defa858)

## Configurazione del master
![a9875aa78f80be691fcfecd6875b231c.png](:/3175594998c9462e80b4c4f9aac7d197)
"segreto" è il nome della chiave.
Tra le virgolette dopo *secret*  abbiamo la chiave simmetrica da usare.
Il dominio nic.it può essere trasferito tramite la chiave segreto.

## Configurazione dello slave
![e3be830e114ed1b9d829cc6988ec198c.png](:/e5d9d5e0fed54260b50c807ad3ea399f)
Quando ci si collega al server dns.nic.it che è autoritativo per nic.it utilizza la chiave *segreto* e inoltre indico che il dominio nic.it è di tipo slave.

## Nuovi resource record
![15385d1b4aed4e8b11bade2dbaa7ec42.png](:/c42b0aac25a34d4f894bdfa8b17daf9e)
![1c58dde72bf3e40ad927d786e0d5b66d.png](:/32eb442c84e6407aa189f478b9aa7e73)

### DNSKEY
La ZSK serve per firmare tutti i record di una specifica zona.
Con la KSK invece non vengono firmati i RR di una zona ma vengono firmati i RR di tipo DNSKEY.
![0a2242c6538220c429a6687aeafe1369.png](:/b663edaa7f43408fb7d985be4f5f53ea)

### RRSIG
![3698b3d6fd722a23b3e454534ec18125.png](:/24804baafaca4f70abdc240296a8e64b)
![70bba53df2d0e88287116ca63933528f.png](:/12ed5451b703419b995d46ac5d9443ae)

### DS
![960c9b402c6137ce32953127fabbfa03.png](:/13a44ec515f04bc78255b9684b87cbb6)
analogo al concetto del nameserver ma per quanto riguarda le chiavi.
Il Key Tag è fondamentale in fase di diagnosi e verifica dei malfunzionamenti in quanto questo record deve corrispondere al record della DNSKEY per la KSK:
![0e245ff7ac124abd5c538040d97366d0.png](:/af273395db564da3b5e144db06599a93)
Il record DS che corrisponde alla chiave pubblica associata a questa DNSKEY deve avere lo stesso Key Tag.

### NSEC
![792be0486b2675c639073d4beac47d71.png](:/21d91da68fe14ff298d445ed2080fcf9)
![d98e1fa3834ce48f57eff2c1c7baa9b7.png](:/f970460dd56946d2904a9751267e150a)

# Chain of Trust
![89ddcc5bfc1a28888ef615ff71c3c76c.png](:/3292a4b261fd475b9e0b459a53bf940d)
Con l'utilizzo del record DS per implementare la chain of trust non ho bisogno di avere una chiave per ogni nameserver ma è sufficiente avere una chiave per ogni dominio.
![40b890e47fcc4035da001a7e23f5864d.png](:/5ee75027f90a4b92ae4aa52add82ec7b)
La parte in alto è la route zone, dunque la zona della radice ovvero quella che contiene i ccTLD e i gTLD e i name server autoritativi per quei TLD. Oltre a queste informazioni con il DNSSEC, la radice contiene anche un record DNSKEY che contiene ZSK e il record DS del **.it** dunque il valore di hash che è generato a partire dalla KSK del **.it**.
Se esistono N domini che usano il DNSSEC, per tutti quelli firmati digitalmente ho il record DS che sono derivati dalla KSK della zona figlia:
![2201ff188ea8eee61f4250805813f395.png](:/ee6867185bed4a7ab051b967c3acce33)
![277a19a80fbcf2e1570811d4718a83e6.png](:/12f39b326b83453ab4fc59a4259748a3)
![8e79846999f7dbd3f8300f7abec3e864.png](:/8295210f48074a918ceb43abfb2450b9)

## DNSSEC: Firma di una zona
![d8e75c7d8df2a2d96195115c913ec862.png](:/15246c09cbb742b3872c4dd788844a8e)

![5d1a042896a0d81bdde4ee4d5d99a347.png](:/6701df331d04455ab58879df71c1a799)
![c0b4fe1b74c18172d317bd01726c6fcb.png](:/12327716c4d849c6b9666e4a32e79266)

### Esempio di configurazione del primario:
![7eea2cc322c89bad66d65f5da0d21db8.png](:/29b5d08c8613417e81cdfdeed333b387)

![387601ba805f27f5dae4c164183a4d2a.png](:/81cc422547ec4e2d83e5d9f988e3218a)

![eed2f7c25f56ad985b8d11f785d4d836.png](:/2fad2b5e42784ad89a811384b9a61333)
![78157580496e7a7108c74417831cb218.png](:/a4470e4e9a16409694a289db16a7ff16)

* * *
* * *
**22/09/2023**
Analisi pcap Emotet

* * *
* * *
**30/09/2023**
![2daa41551430e17fa9877234164d8e54.png](:/1225f3df47e146ae8a290b0dd76ddf71)
Non vuol dire decriptare il traffico di rete ma analizzare un traffico che è criptato.
![f6201094849768a28af07db4c80c729d.png](:/b2f6102263a44ff5856dd728ae362291)
Se cambia il fingerprint di un dispositivo potrebbe essere successo che qualcuno lo ha modificato cancellando le chiavi RSA oppure sta effettuando un attacco MITM.
Dal punto di vista del traffico di rete Salesforce si è inventata una serie di algoritmi:
![ee7c3654b361cbc6d4572c41924236c6.png](:/6521f4aced8b43f68d0bc2fbb50d37c2)
![88d66229637eb34762a59f5bd92bcc4c.png](:/4ebebc206228491bb770c4967b2a8343)
Nella fase iniziale il client comunica al server gli algoritmi conosciuti da lui. Si può creare un fingerprint sfruttando proprio questa fase di negoziazione iniziale e farci un hash di questi campi per accorgermi di un eventuale MITM. Il calcolo dell'hash (HASSH) viene fatto per il client e per il server.
![c130d4b327a92b9131e3cf5ea9f10095.png](:/3ad2b27570ba4fbbbd4f517d33e264e7)

Grazie al parametro risk che è possibile ottenere dall'analisi di un flow di rete con ndpiReader con il parametro -v 2 otteniamo alcune descrizioni:
![fdd9b49c8e58d38dbc30b5dce578521e.png](:/4b470901eb104d88ba929be1e2a2db98)

![4959a67daee990e517ba657db03d7b30.png](:/fa028bbc2a364cd1ad080d43886164b4)
![ec07c6490bba9682d9f07fbb543abebc.png](:/0d767bf96d25413fbdacc92c2997d0d0)
![2fe066ef520cece45074bbae2adeb547.png](:/7bc4162c86594b8f80b0192d94e16fd5)
Il JA3 serve per fare il fingerprint del client e del server ma è diverso dal fingerprint dell'utente che si sta connettendo ad esempio in ssh (quello mostrato in SHA256 quando ci si connette in ssh).

`ndpiReader -i tests/pcap/instagram.pcap -v 2`

La **cat** sarebbe la categoria in ndpiReader del traffico che si sta analizzando:
![717b51fd2e00fb0d27523183237fd0f0.png](:/ca310ccb18b64626bd7594ddfa28196c)




## RECUPERO LEZIONE OPZIONALE 05/10/2023


* * *
* * *
**06/10/2023** 
# Esercitazione
![c2c570fde306a5f21d6db4880e52b3c5.png](:/30a0f91bbaf545df9d600cf5bfb3eb31)
![f8108b472864749e2a7d63f19e729688.png](:/5e33e7d2731543a9a710f718791f2873)
![f7d54e575fc604d4d02a724ae8501cc0.png](:/0c7e031fe60045feab826ce2d0a7eccc)
![1d160d896112c5894751551e407abb00.png](:/b1312c67e6944eed8f7109387c7df293)
![63cc3bd0ba388682d839dea82475f1d1.png](:/618674f8b74d4191bdb0e273a880ea3d)
![0af8a588f8497ae84a8cf423e95dedac.png](:/e9dfb4fd62324b53907d14da325f93ed)
![f7075033fd96dc88f5680864a7f97eac.png](:/c57bcbf78bc947c1ba61ebc3f70b1fd4)
![61c8acf4d30c537371239b861dc1477e.png](:/4956d3ac1b88435683a4a582cd3cea46)


## Configurazione della zona
![215ead4ede8159483f90bf34be66e5a6.png](:/02e881f5cced439f80940b631dbaf002)

## Configurazione di BIND
![c388903cc019a75f128098c8ac7aa4c4.png](:/1fcabbff4b994b71bf1de2f444f0911a)
![e191fdc5f3ea03e23326eded988e03ec.png](:/c8f0679829734de78a5853912d7a7391)

## Controllo della configurazione e reload della configurazione
![3bc28371c66e949c24b8eb6e161e12b1.png](:/3c18ecd24c5b4119b0cc8ad1eeb5e3b8)
![616737fb78d1465bacd9ec698c6fe57a.png](:/caded9d8f5c841708b150d2e6e806018)

## Configurazione del trasferimento di zona
![a2ce41560d6a0afe0c994788c71e177c.png](:/a451bed93e2749fb901a8028b6a00112)
![f3eb2af23e992cbf80d685d0121498e8.png](:/5516a4e6b56f427fa189e62ed7f10a28)
![145d020ad0ca56b246f9cdf2f7eea751.png](:/f3ce5a5ea317472ea65a1dc3d0aa0474)

# Trasferimento di zona sicuro tramite chiave
![d2f2a02916e23cfb21a7caa9dd20be69.png](:/f886539d92894f6689bd475c51623907)
![cc3857ed05fd48d1e005c17a9908ea76.png](:/0cfe72ad703a473a92308bd111cd9a26)
![707bcdc25d5300e2c42140a4dbee9f50.png](:/05f2a4b700454bb68d9bc75563a9b2d4)
![cc9e022bda7c4f401c154d748c9f3ff2.png](:/c2b636e5ede042b5a7a8654fea1ce2d9)
Il blocco `server` specifica quale chiave bisogna usare quando ci si presenta per la comunicazione con il server di interesse.
![f915b4bda5baa08603069be03ff2ee5b.png](:/ee4c59fdf4c742fd87abeba7f3c438fa)
![253fb8b5f3f3197b2efdd8a526052189.png](:/79f2af95bb6c45ddb68af56fbfed9127)
![f3622fce408fec4ffa0fc4e73e83b7ec.png](:/1e465b193ca54605b001bb891ff95015)
***
***
**27/10/2023**
# Laboratorio

![cedddfc6f07471e71202934df96b2330.png](:/65edeb65236045d1b4fa5b00ea430663)
![2e5378131681d037a410abb35c95620f.png](:/9363e5963e91416ca99a4d13487f52e3)
![0703093b19ee5d8e54bda96d693664f4.png](:/5785eb5d10354ef39f136006eb8e5fc4)
![782e9499c0683da729b43b63d182458d.png](:/337f1c2b717d4527845a2c1d73ba3936)
Il cambio delle chiavi prevede diversi metodi:
![82df20eb0e1c5dc0125cba10e7713055.png](:/9c49dc0cf255408eb29ec99872336d72)
Ciclo di vita di una chiave:
![aa6a215a59e401150ac8b10ef588b802.png](:/56371e4d088e442bac432a6e138286b3)
![7c92950a5f18500ac5a6772609115032.png](:/10a294912f1244e9aefd42c3931d58cc)
![3aafd986150a1c5ecf7897b399d12e9a.png](:/86a1dce05fc94ab89ad181a95323510a)
![3701205cbeba9fa875f9227f05f017b1.png](:/baf5266fc5b84cbf94935668261ff466)






id: c8f47acf1cee4e66ac9adbac470d53df
parent_id: 7582a188cc2e4360b1b1069e40f1fa0d
created_time: 2023-09-08T12:11:47.713Z
updated_time: 2023-10-27T14:29:44.545Z
is_conflict: 0
latitude: 45.46542190
longitude: 9.18592430
altitude: 0.0000
author: 
source_url: 
is_todo: 0
todo_due: 0
todo_completed: 0
source: joplin-desktop
source_application: net.cozic.joplin-desktop
application_data: 
order: 0
user_created_time: 2023-09-08T12:11:47.713Z
user_updated_time: 2023-10-27T14:29:44.545Z
encryption_cipher_text: 
encryption_applied: 0
markup_language: 1
is_shared: 0
share_id: 
conflict_original_id: 
master_key_id: 
user_data: 
type_: 1