f7075033fd96dc88f5680864a7f97eac.png

id: c57bcbf78bc947c1ba61ebc3f70b1fd4
mime: image/png
filename: 
created_time: 2023-10-06T12:48:36.972Z
updated_time: 2023-10-06T12:48:36.972Z
user_created_time: 2023-10-06T12:48:36.972Z
user_updated_time: 2023-10-06T12:48:36.972Z
file_extension: png
encryption_cipher_text: 
encryption_applied: 0
encryption_blob_encrypted: 0
size: 62786
is_shared: 0
share_id: 
master_key_id: 
user_data: 
blob_updated_time: 1696596516972
type_: 4