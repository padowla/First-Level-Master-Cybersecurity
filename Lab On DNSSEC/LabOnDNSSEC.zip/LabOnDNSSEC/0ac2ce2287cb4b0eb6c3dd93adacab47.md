20c4fd5ef924eaf5a0ccf52c356f4ff5.png

id: 0ac2ce2287cb4b0eb6c3dd93adacab47
mime: image/png
filename: 
created_time: 2023-09-08T12:38:01.303Z
updated_time: 2023-09-08T12:38:01.303Z
user_created_time: 2023-09-08T12:38:01.303Z
user_updated_time: 2023-09-08T12:38:01.303Z
file_extension: png
encryption_cipher_text: 
encryption_applied: 0
encryption_blob_encrypted: 0
size: 374684
is_shared: 0
share_id: 
master_key_id: 
user_data: 
blob_updated_time: 1694176681303
type_: 4