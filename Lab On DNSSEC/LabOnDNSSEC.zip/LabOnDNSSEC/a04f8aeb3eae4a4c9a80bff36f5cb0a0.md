418e78bd5b1c5ce37a0f0a5528fbfbe1.png

id: a04f8aeb3eae4a4c9a80bff36f5cb0a0
mime: image/png
filename: 
created_time: 2023-09-14T21:14:19.656Z
updated_time: 2023-09-14T21:14:19.656Z
user_created_time: 2023-09-14T21:14:19.656Z
user_updated_time: 2023-09-14T21:14:19.656Z
file_extension: png
encryption_cipher_text: 
encryption_applied: 0
encryption_blob_encrypted: 0
size: 306268
is_shared: 0
share_id: 
master_key_id: 
user_data: 
blob_updated_time: 1694726059656
type_: 4