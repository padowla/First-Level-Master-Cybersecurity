f915b4bda5baa08603069be03ff2ee5b.png

id: ee4c59fdf4c742fd87abeba7f3c438fa
mime: image/png
filename: 
created_time: 2023-10-06T14:56:42.396Z
updated_time: 2023-10-06T14:56:42.396Z
user_created_time: 2023-10-06T14:56:42.396Z
user_updated_time: 2023-10-06T14:56:42.396Z
file_extension: png
encryption_cipher_text: 
encryption_applied: 0
encryption_blob_encrypted: 0
size: 56283
is_shared: 0
share_id: 
master_key_id: 
user_data: 
blob_updated_time: 1696604202396
type_: 4