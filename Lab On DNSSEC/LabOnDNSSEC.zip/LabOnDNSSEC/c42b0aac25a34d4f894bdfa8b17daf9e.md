15385d1b4aed4e8b11bade2dbaa7ec42.png

id: c42b0aac25a34d4f894bdfa8b17daf9e
mime: image/png
filename: 
created_time: 2023-09-15T12:56:35.519Z
updated_time: 2023-09-15T12:56:35.519Z
user_created_time: 2023-09-15T12:56:35.519Z
user_updated_time: 2023-09-15T12:56:35.519Z
file_extension: png
encryption_cipher_text: 
encryption_applied: 0
encryption_blob_encrypted: 0
size: 259567
is_shared: 0
share_id: 
master_key_id: 
user_data: 
blob_updated_time: 1694782595519
type_: 4