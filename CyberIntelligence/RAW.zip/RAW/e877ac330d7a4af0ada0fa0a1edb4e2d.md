11667544a81531bd120a4ab0c1c48a13.png

id: e877ac330d7a4af0ada0fa0a1edb4e2d
mime: image/png
filename: 
created_time: 2023-06-09T14:13:21.854Z
updated_time: 2023-06-09T14:13:21.854Z
user_created_time: 2023-06-09T14:13:21.854Z
user_updated_time: 2023-06-09T14:13:21.854Z
file_extension: png
encryption_cipher_text: 
encryption_applied: 0
encryption_blob_encrypted: 0
size: 107705
is_shared: 0
share_id: 
master_key_id: 
type_: 4