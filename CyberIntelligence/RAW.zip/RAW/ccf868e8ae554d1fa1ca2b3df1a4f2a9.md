0041cf6b9493beef2afe45b797aa139b.png

id: ccf868e8ae554d1fa1ca2b3df1a4f2a9
mime: image/png
filename: 
created_time: 2023-06-24T07:05:28.359Z
updated_time: 2023-06-24T07:05:28.359Z
user_created_time: 2023-06-24T07:05:28.359Z
user_updated_time: 2023-06-24T07:05:28.359Z
file_extension: png
encryption_cipher_text: 
encryption_applied: 0
encryption_blob_encrypted: 0
size: 126713
is_shared: 0
share_id: 
master_key_id: 
type_: 4