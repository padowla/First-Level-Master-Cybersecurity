c1ff9ad72820e36822f5e9ccd11f0dac.png

id: 6e70006dff93405ebfc3fdbe1da1bf7d
mime: image/png
filename: 
created_time: 2023-02-17T17:17:55.147Z
updated_time: 2023-02-17T17:17:55.147Z
user_created_time: 2023-02-17T17:17:55.147Z
user_updated_time: 2023-02-17T17:17:55.147Z
file_extension: png
encryption_cipher_text: 
encryption_applied: 0
encryption_blob_encrypted: 0
size: 139223
is_shared: 0
share_id: 
master_key_id: 
type_: 4