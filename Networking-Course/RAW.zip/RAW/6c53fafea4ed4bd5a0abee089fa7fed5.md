61bb41e8a9e0fdf3df6bb32f3da5a869.png

id: 6c53fafea4ed4bd5a0abee089fa7fed5
mime: image/png
filename: 
created_time: 2023-02-17T17:21:01.830Z
updated_time: 2023-02-17T17:21:01.830Z
user_created_time: 2023-02-17T17:21:01.830Z
user_updated_time: 2023-02-17T17:21:01.830Z
file_extension: png
encryption_cipher_text: 
encryption_applied: 0
encryption_blob_encrypted: 0
size: 229872
is_shared: 0
share_id: 
master_key_id: 
type_: 4