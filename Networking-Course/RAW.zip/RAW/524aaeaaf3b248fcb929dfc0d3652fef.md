9c04a1e20261226fbcf950faa34d93f5.png

id: 524aaeaaf3b248fcb929dfc0d3652fef
mime: image/png
filename: 
created_time: 2023-02-25T08:48:29.407Z
updated_time: 2023-02-25T08:48:29.407Z
user_created_time: 2023-02-25T08:48:29.407Z
user_updated_time: 2023-02-25T08:48:29.407Z
file_extension: png
encryption_cipher_text: 
encryption_applied: 0
encryption_blob_encrypted: 0
size: 107574
is_shared: 0
share_id: 
master_key_id: 
type_: 4