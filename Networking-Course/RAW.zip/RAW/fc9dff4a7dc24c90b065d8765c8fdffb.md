3065a4c3cfb8df3ef93498d973bc5fd8.png

id: fc9dff4a7dc24c90b065d8765c8fdffb
mime: image/png
filename: 
created_time: 2023-02-17T18:14:02.391Z
updated_time: 2023-02-17T18:14:02.391Z
user_created_time: 2023-02-17T18:14:02.391Z
user_updated_time: 2023-02-17T18:14:02.391Z
file_extension: png
encryption_cipher_text: 
encryption_applied: 0
encryption_blob_encrypted: 0
size: 260567
is_shared: 0
share_id: 
master_key_id: 
type_: 4