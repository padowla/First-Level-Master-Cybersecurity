7bb9fa420330836dfa687c2555780250.png

id: 4c30c47e76c446ea84dacaefdce6d5c0
mime: image/png
filename: 
created_time: 2023-02-18T07:34:58.592Z
updated_time: 2023-02-18T07:34:58.592Z
user_created_time: 2023-02-18T07:34:58.592Z
user_updated_time: 2023-02-18T07:34:58.592Z
file_extension: png
encryption_cipher_text: 
encryption_applied: 0
encryption_blob_encrypted: 0
size: 230953
is_shared: 0
share_id: 
master_key_id: 
type_: 4