06cfc3bf15a5b2f363d689126a3398c2.png

id: d4e99328fc0e4c54acffac4c9a2eed79
mime: image/png
filename: 
created_time: 2023-02-04T08:43:58.372Z
updated_time: 2023-02-04T08:43:58.372Z
user_created_time: 2023-02-04T08:43:58.372Z
user_updated_time: 2023-02-04T08:43:58.372Z
file_extension: png
encryption_cipher_text: 
encryption_applied: 0
encryption_blob_encrypted: 0
size: 36819
is_shared: 0
share_id: 
master_key_id: 
type_: 4