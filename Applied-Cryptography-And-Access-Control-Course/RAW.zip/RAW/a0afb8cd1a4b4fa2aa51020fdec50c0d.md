Teoria

04/02/2023

## Introduzione
- Docente: Gianluca Dini, Pericle Perazzo
- Mail: gianluca.dini@unipi.it
* * *

Dobbiamo considerare che abbiamo un avversario che vuole attaccare il nostro sistema.
L'avversario cercherà di violare:
1. Confidenzialità
2. Integrità
3. Disponibilità

La crittografia ci permette di proteggere la confidenzialità e l'integrità dei dati.
La disponibilità si protegge in altri modi che non sono metodi crittografici.
Parleremo di <span style="color: #ff536a">crittografia applicata</span> in quanto non progetteremo algoritmi crittografici perchè inerente l'ambito matematico. Noi invece ci chiederemo come usare gli algoritmi per proteggere i dati trasmessi in rete. Ci interessa la parte applicativa. Cos'è un certificato, quali vantaggi mi da una firma digitale, etc...

***

![86c8f5828233b1aeb41f6eef238e509f.png](:/8f3627d4b1894608a7410ca2111b7bc6)


La storia ci insegna che nella maggior parte dei casi gli algoritmi crittografici "home-made" possono essere facilmente rotti. La best practice è quella di usare sempre algoritmi standard, ovvero progettati dai migliori crittografi in circolazione che sono stati attaccati e analizzati e alla fine di questo processo è stato deciso che si trattava di algoritmi sicuri e prestazionali.

La crittografia è importante in quanto nei servizi e apparati che usiamo la troviamo ovunque:
- HTTPS: Web Traffic
- Wireless Traffic: 802.11i WPA2, GSM, Bluetooth
- File cifrati su disco: EFS, TrueCrypt
- Protezione dei media: DVD(CSS) e Blu-ray (AACS)
***

## Cosa significa "Security" ❔
![689128848448f4b03620ecdbbf4d7c16.png](:/a024f293e72942c4bea59812d47d0e4a)
1. Se abbiamo una dimostrazione matematica per cui un algoritmo è sicuro quell'algoritmo è sicuro matematicamente. Esiste un algoritmo di questo tipo ma è male utilizzabile nella pratica quindi si usa molto poco. Ne vedremo un esempio dopo.

2. "Rompere quell'algoritmo matematicamente parlando o in termini di tempo è tanto difficile quanto risolvere un problema complesso". Se abbiamo un numero con 100 cifre decimali, fare la fattorizzazione è molto difficile, quindi anche usando i migliori elaboratori ci vogliono migliaia di anni. Se dimostro che rompere quell'algoritmo corrisponde a velocizzare la fattorizzazione, posso stare sicuro. Si tratta del caso della crittogradia asimmetrica.

3. Non ha dietro una dimostrazione matematica ma una prova sperimentale in cui i migliori crittografi ben equipaggiati hanno provato a romperlo ma non ci sono riusciti.

4. Scenario in cui c'è un numero enorme di chiavi di crittografia per cui potrei provarle tutte ma sono talmente tante che ci vorrebbe una quantità di tempo impraticabile. Mettendoci anche un microsecondo ci vuole una quantità di tempo inestimabile. Questa non è neanche una definizione di sicurezza.

Ci sono 4 livelli diversi di sicurezza e ogni algoritmo cerca di coprirne almeno 3. Vedremo anche in quale di questi ogni algoritmo si colloca.

## Cryptography
<span style="color: #00ff7f">È</span>: uno strumento molto utile e le fondamenta per molti meccanismi di sicurezza

<span style="color: #ff7f7f">Non è</span>: la soluzione a tutti i problemi, affidabile se implementata e usata in modo sbagliato e qualcosa da inventare e usare per conto nostro

# Primitive crittografiche

## Cyphers

### Cifrari simmetrici
![733fa3a9585401bd57d6643e5bec8b83.png](:/e8671035fd0d4708a3b602bae10dfd78)
Lo scenario di riferimento contiene due interpreti principali (**Alice** e **Bob**) che vorranno comunicare tra di loro attraverso una rete di calcolatori. Un esempio potrebbere essere che Alice usa il suo laptop per collegarsi al server di Bob. 

L'attaccante cercherà di violare la confidenzialità delle comunicazioni (++eavesdropping++) e/o alterare l'integrità della comunicazione (++tampering+). 
- <span style="color: #ff536a">eavesdropping</span>: ad esempio Alice invia la password a Bob e l'attaccante può ++**rubare**++ la password
- <span style="color: #ffcf00">tampering</span>: durante una transazione bancaria da Alice a Bob, l'attaccante ++**modifica**++ il destinatario della somma di denaro inviandoli a se stesso

Per lo meno vorremmo che il tampering sia rilevato.

Lo scenario è il medesimo del seguente:
![dc8dd5a2aef7256c296f8b87a2633454.png](:/b52c062e2269416aa69193ab0831ade7)

Alice salva un file in un repository e poi lo va a rileggere. E' come se Alice parlasse con se stessa, perchè salvare un file su un disco è come se la Alice di oggi parlasse con la Alice di domani, in quanto il file lo rileggerà nel futuro (domani, o tra un mese). Vogliamo proteggere la modifica del file.
![dcf092908949b44bfcc00c6b0c2dc20f.png](:/2b731a2df3ba4266b7d98e52a2ca65a5)

Alice e Bob dispongono di un algoritmo di crittografia che è detto <span style="color: #007dff">**cifrario** </span>costituito da una coppia di funzioni o algoritmi:
- La funzione `E` è l'algoritmo di cifratura (<span style="color: #7f77ff">encryption</span>). Prende in ingresso una chiave `K` che è un segreto da immaginare come una sequenza di bit (es: 010100010) che tipicamente ad oggi è dell'ordine di 128 bit. Come si genera una chiave `k` in modo intuitivo? Prendo una "moneta", lanciandola, in base al risultato stabilisco il valore dei bit, ovvero se esce testa ==> 1, se esce croce ==> 0, la lancio 128 volte e segno i 128 valori. Questa funzione usando i parametri di input mi restituisce il crittogramma `c` che è la cifratura del testo in chiaro da cifrare `p`. Questo `c` verrà inviato sulla rete e noi ipotizzeremo che il nostro avversario sia così bravo da intercettare `c`. Questo è il threat model d'esempio.

- La funzione `D` è l'algoritmo di decifratura (<span style="color: #ff536a">decryption</span>). `c` arriverà a Bob che prende in ingresso anche la stessa chiave `k` e l'algoritmo `D` restituirà il messaggio originario inviato da Alice.

Sia Alice che Bob avranno la loro coppia identica di funzioni `D` ed `E` (es. librerie python o chip elettronici sulla scheda di rete). La chiave `k` è un segreto condiviso tra Alice e Bob e non deve essere pubblico. La sicurezza di questo sistema che protegge la confidenzialità della comunicazione si basa sulla complessità di `k`.

Se chiunque conosce la chiave `k` ovvero la sequenza esatta di 128 bit ad esempio, prenderebbe `c`, userebbe l'algoritmo `D` che è pubblico, e otterrebbe `p`. 

❓️Come fanno Alice e Bob ad avere un segreto condiviso `k`

Potrebbero incontrarsi  e scambiarselo al bar, ma funziona meno bene questa soluzione se il client e il server si trovano in locazioni geografiche molto distanti. Come lo stabiliscono è un problema e lo vedremo più avanti. Alice da casa sua potrebbe lanciare la moneta e definire `k` e inviarla a Bob ma mandandola in chiaro l'avversario la intercetterebbe e non sarebbe più sicura la comunicazione. Per mandarla in rete in modo protetto dovrei cifrarla ma per farlo ci vorrebbe un altra chiave `K`<sub>`1`</sub> e il problema si ripeterebbe. Si può interrompere o con metodi OFFLINE (si incontrano al bar o usando un altro mezzo di comunicazione, la lettera postale con dentro il pin che la banca ci invia a casa è un esempio di mezzo di comunicazione alternativo utilizzato nella realtà) oppure ONLINE ovvero raggiungere un segreto condiviso attraverso la rete stessa definita come insicura, ad esempio il TLS mi permette di raggiungere questo obiettivo ma per farlo è necessaria la crittografia a chiave pubblica.

Per ora il nostro assunto è:
✅ Alice e Bob hanno un segreto `k` condiviso
✅ L'attaccante conosce gli algoritmi utilizzati `D` ed  `E`
✅ L'attaccante può intercettare `c`

![1ca21be2fa8de17837b6d9c7a75ed222.png](:/739a0763d5fd460a807ac70d15543bda)

Per far si che tutta la sicurezza sia concentrata in `k` e non nel resto è necessario che dato `c` deve essere difficile determinare `p` senza conoscere la chiave `k`. Di tutte le funzioni `D` ed `E` che posso inventarmi devo trovare quelle per cui deve essere molto difficile trovare `p` non conoscendo `k` e avendo solo `c`. Questa proprietà dipende dal fatto che il mio avversario può intercettare qualsiasi messaggio. Se il mio sistema è sicuro deve esserlo per ogni comunicazione. Dati `c` e `p` deve essere inoltre difficile ottenere la chiave `k`, a meno che non sia usata una volta sola (questa clausola verrà compresa più avanti quando parleremo del cifrario di Vernam):
![8f1241c4a0ff80296716af6b9182696a.png](:/baa379f0f77e4a61ab53d4f263319e3a)
L'avversario cercherà di violare almeno una di queste 2 proprietà tramite la <span style="color: #ffc86c">crittoanalisi</span>, ovvero *lo studio delle tecniche matematiche per rompere l'algoritmo crittografico ovvero violare queste 2 proprietà*. Le ipotesi sono: l'avversario ha accesso ai dati trasmessi in forma cifrata ovvero intercettare qualsiasi cosa e l'altra è l'ipotesi di Kerckhoffs ovvero l'avversario conosce tutti i dettagli degli algoritmi di cifratura in quanto pubblicamente reperibili.

***
📖
In crittografia, il principio di Kerckhoffs (conosciuto anche come legge di Kerckhoffs), enunciato per la prima volta da Auguste Kerckhoffs alla fine del 1880, afferma che un crittosistema deve essere sicuro anche se il suo funzionamento è di pubblico dominio, con l'eccezione della chiave.
***

Tenere segreti gli algoritmi `E` e `D` storicamente non ha mai funzionato: la Security trough Obscurity (vedi film ENIGMA). In genere `E` e `D` sono scritti nel firmware delle schede elettroniche, se fossero sconosciute a tutti tranne che al produttore e dovessero essere venir rotte da un attaccante, il produttore dovrebbe ritirare tutte le schede elettroniche dal mercato, cambiare `E` e `D` e ridarle ai propri clienti. Cosa diversa se le funzioni hanno passato una fase di criptoanalisi condivisa a livello globale da diverse istituzioni e standardizzata e dunque conosciuta da tutti.

#### 👥Esempi di cifrari simmetrici👥
<span style="color: #000000"><span style="background-color: #ffc8ab">Algoritmo a sostituzione monoalfabetica</span></span>
![137e4379c644c4f71becbe87672f526e.png](:/faf4c73e6a1a431c92dff17d45b99c6a)
Nell'esempio, `P`<sup>`'`</sup>  contiene le lettere raggruppate a gruppi di 5 solo per evitare di mappare le lettere 1:1 e rendere l'attacco più facile del previsto.

L'avversario in rete intercetta `C` e vorrebbe ricavare `P`. L'avversario potrebbe iniziare a ragionare sui caratteri ma quello che sicuramente può fare l'avversario è eseguire un' <span style="color: #ff7f7f">attacco esaustivo alle chiavi</span> o anche detto <span style="color: #ff7f7f">attacco a forza bruta o brute-force</span>, fin quando non ottiene un messaggio avente un senso compiuto. Se lui fa un attacco a forza bruta deve provare tutte le possibili permutazioni, con `n` elementi le permutazioni sono `n!`.
In questo caso 26! è circa 4 x10<sup>26</sup> e se anche ci mettesse un microsecondo per ogni permutazione ci vorrebbe troppo tempo. Questo significa che è **DIFFICILE**. Visto così questo algoritmo sembrerebbe molto sicuro, perchè ci vuole molto tempo per un attacco a forza bruta. 

Le lettere però non sono tutte equiprobabili nei testi scritti. Nella lingua inglese la lettera che appare più frequentemente è la lettera 'E' 'T' ed 'A'. Se la lettera più frequente nella lingua inglese è la 'E', ma con l'algoritmo di crittografia dell'esempio io la trasformo in 'S', troverò molte 'S' ed è molto probabile che corrisponda alla lettera 'E'.
![06cfc3bf15a5b2f363d689126a3398c2.png](:/ee8e9ebdcbce418693145e6974d1c204)
Si può ragionare anche per coppie di lettere (es. TH in inglese è molto frequente).
Sfruttando le statistiche del linguaggio è possibile crittoanalizzare il testo cifrato e trovare la chiave.

***
**11/02/2023**

L'altra volta abbiamo fatto alcune considerazioni generali e abbiamo visto un primo cifrario ovvero quello a sostituzione monoalfabetica. Abbiamo visto in un caso semplice cosa vuol dire attaccare un cifrario. 

# Perfect cypher
Un cifrario perfetto esiste, è molto semplice da realizzare, è stato realizzato in pratica ma capiremo perchè non lo usiamo tutti i giorni.

❔Un cifrario perfetto cosa vuol dire?
Shannon nel **1949** diede una definizione matematica, in quegli anni di guerra esisteva Turing e al tempo stesso in America c'era Shannon con Von Neuman: 
- *"Un cifrario è perfetto se non rivela alcuna informazione sul testo in chiaro"*
Se la coppia di algoritmi `E` e `D` vuol dire che l'avversario intercetterà tutto il testo cifrato possibile ma non riuscirà ad ottenere alcuna informazione riguardo il testo in chiaro.

- Inoltre se riusciamo a costruire un cifrario perfetto, non ci interessa nemmeno la ++potenza computazionale<span style="color: #ff0000"></span>++ dell'avversario, ovvero si può ipotizzare che si trovi in una condizione di capacità di calcolo infinita.
- 💡<span style="color: #000000"><span style="background-color: #ffff00">Teorema di Shannon</span></span>
Se riuscissimo a costruire un cifrario perfetto , si può dimostrare che il numero delle chiavi deve essere maggiore o uguale del numero dei messaggi.
![3ad0971d19c1d743cf86f1635119fbae.png](:/318d46aa53a143d1a31700fbdaaf9395)

## One Time Pad
Il cifrario perfetto esiste e si chiama **One Time Pad** (Vernam cipher, 1917).

Supponiamo che il testo in chiaro sia sostanzialmente una sequenza di bit. Ogni casella è un bit e può contenere o il bit 0 il bit 1. Chiaramente se l'avversario la intecetta si troverà con la sequenza di bit, e magari se conoscesse a priori che Alice e Bob si stanno scambiando un PDF potrà interpretare la sequenza come PDF, ovvero l'avversario non esegue mai l'attacco alla cieca ma parte già con una conoscenza pregressa. Il cifrario di Vernam prevede di prendere una chiave `K` che ha tanti bit quanti sono i bit del messaggio. ⚠️ ==**La chiave viene costruita in modo randomico**== ⚠️ . A questo punto viene eseguita l'operazione di **OR ESCLUSIVO (XOR)** bit a bit. Ovvero per ogni coppia di bit partendo dalla prima coppia, usando l'operazione XOR, produco il cipher text.
![38ecf07e7edb3645414cbcb511c888fa.png](:/862ee5dbccdf4f07bd2194cbde877c51)
Le operazioni bit a bit sono estremamente efficienti e veloci. Si tratta di un operazione molto semplice, veloce e poco costosa computazionalmente parlando, quindi da un punto di vista implementativo è ideale.

⚠️ **XOR**
Si tratta di un operazione logica binaria. Per definizione se i due bit sono diversi il risultato è 1 altrimenti se sono uguali ritorna 0.
|  p |  k | c |
|--- |--- |---|
| 0  | 0  | 0 | 
| 0  | 1  | 1 |
| 1  | 0  | 1 | 
| 1  | 1  | 0 |
⚠️ 

![a91494dd73a6529a9c3a3d1ef2026a2b.png](:/03133d88411845ef89aec9658e8f0799)

Si può dimostrare che conoscendo il testo cifrato `c`, è possibile decriptare riapplicando lo XOR con la chiave `k` in possesso.

Possiamo dimostrare che se la chiave è ++<span style="color: #ff6835">perfettamente random</span>++, allora il cifrario di Vernam è perfetto. 
![a2570c3e88f78baac3e6d7d514b7c920.png](:/a42bf7f5e282412e890a39624676b98e)

*Esempio del perchè il cifrario è perfetto:*
![ed128289c2aba60e3e4f1f87c6e2e692.png](:/561c3a881e2f49029320fa09f31a4d20)

Scenario: james bond deve andare in missione in nazione straniera, quindi il suo capo manda un messsaggio `m` all'agente di supporto in cui dice "supporta james bond". La chiave che viene generata è `k` ma non sto usando i bit ma i caratteri. Qui c'è una complicazione...

⚠️ Lo XOR è una somma a singolo bit in base 2, qui stiamo facendo una somma in singola cifra in base 26. Il concetto è che se prendiamo le prime lettere di `m` e `k` ovvero 'S' e 'W', usando l'alfabeto inglese che ha 26 caratteri, alla A associo il valore 0, B il valore 1 ... alla Z il valore 25. S + W mi porta sulla lettera O in quanto essendo modulare in base 26 è ciclico su 26 caratteri posssibli, è come se l'alfabeto fosse circolare.
![76406562fa9044aa284d5ba7d046a313.png](:/9d11429a82d74badb7f48feae90a0f69)
Si può dimostrare che questo corrisponde a fare lo XOR.
⚠️

`c` è il messaggio che viene trasmesso in rete. Questo viene intercettato dall'avversario il quale vuol cercare di capirci qualcosa, ma essendo perfetto non riesce. Può però provare un attacco a forza bruta ovvero provare tutte le possibili chiavi. Avendo un messaggio di 16 caratteri con un alfabeto di 26 caratteri avremmo **26^16^** possibili chiavi.

Pur provandole tutte lui otterrà da ogni possibile chiave un plaintext, ovvero tutti i possibili messaggi su 16 caratteri. Tra questi messaggi ci sarà anche quello che sta cercando ma ce ne sarà anche qualcuno che ha senso compiuto ma non è quello originale mandato, ad esempio:
"CAPTURE JAMES BOND".

<span style="color: #ff6835">Non si usa nella pratica per i seguenti motivi</span>:
![44296a9a5308cb86ffc35ae20ea8f14f.png](:/96bc437c4db4415db230b78a8d5dd98b)
- **<span style="color: #ff0000">la chiave deve essere lunga quanto il messaggio</span>**, per messaggi lunghi diventa impossibile (1gigabit di film da cifrare diventa molto scomodo da un punto di vista pratico, in quanto sarà necessaria una chiave da 1gigabit)
- <span style="color: #ff0000">**la chiave può essere usata una volta sola**</span>, perchè si può dimostrare che l'avversario dai due testi cifrati usando la stessa chiave potrebbe ottenere informazioni riguardo la chiave stessa
- se dispongo del testo cifrato e del testo in chiaro,<span style="color: #ff0000"> **ricavare la chiave è molto semplice**</span>
- **<span style="color: #ff0000">il cifrario è malleabile</span>**: se usassi la chiave una volta non ci sono problemi. L'altro obiettivo è il tampering, ovvero l'avversario potrebbe modificare il messaggio, il problema del OTP è che mentre è sicuro rispetto all'eavesdropping, non ho alcuna garazia sul tampering, ed ancora peggio è ++MALLEABILE++: *ovvero delle modifiche al cipher text da parte dell'avversario non sono rilevabili e inoltre l'avversario riesce ad avere un controllo delle modifiche in modo tale che il ricevente decifri quello che l'avversario vuole*.
![80efcfb49a7c266128d5f6086fb3bf74.png](:/3ac9c4aa25cd423fb848233f3f13fe44)


❗️==I cifrari non sono forti rispetto all'integrità perchè sono progettati per fare altro (confidenzialità). Per questo motivo parleremo di funzioni di hash e firme digitali.==

Come fa l'avversario a sapere che deve mettere esattamente i caratteri al posto di quelli? 
Chiaramente l'esempio è didattico, ma l'avversario potenzialmente può conoscere tutto eccetto le chiavi, quindi potrebbe conoscere la struttura del messaggio di massima, ovver la prima parte è il comando, la seconda parte è la quantità di denaro, la terza parte è la valuta e la quarte parte è il destinatario:
![b52cd59c8e1cdcffc82e42da5d672d6c.png](:/d5293579e5b945e586f93ff572e57b79)

La dimostrazione matematica di malleabilità: 

`r` è la perturbazione introdotta dall'avversario, si può dimostrare che lato ricevente si riceve il testo in chiaro XOR la perturbazione, che non viene rilevata ed ha un impatto prevedibile. Lo XOR esclusivo tra `r` e il testo cifrato mi si propaga sul testo in chiaro. Inoltre `r` è totalmente indipendente dalla chiave `k`.
![4d9fd7542e3340bb7069594f4eb25398.png](:/0af4a13b3b1c47e0acf63dbc99d79833)

Esercizio:
![d62f5f7d0b8f6dbc7d2cd5c62d69ef66.png](:/e8e369e2a6634f41b498c3c40534d4c8)
![8f2cef424b1179b775069b83786a472c.png](:/e291ee05c61f49f1ab06e0efdd03b317)

Trovo le differenze in bit tra pt~Y~ e pt~N~:
pt~Y~: 0 1 0 ++1++ 1 ++0++ ++0++ ++1++
pt~N~: 0 1 0 ++0++ 1 ++1++ ++1++ ++0++

e noto che sono opposti tra di loro (quelli sottolineati). Per invertire un bit basta fare: bit_che_si_vuole_invertire ⊕ 1 dunque la perturbazione r sarà costituita dagli 1 in corrispondenza dei bit che voglio far flippare e degli 0 in corrispondenza di quelli che voglio lasciare intatti:
r : <span style="color: #0055ee">0</span> <span style="color: #0055ee">0</span> <span style="color: #0055ee">0</span> <span style="color: #ff0000">1</span> <span style="color: #0055ee">0</span> <span style="color: #ff0000">1</span> <span style="color: #ff0000">1</span> <span style="color: #ff0000">1</span>

Se la risposta di Alice è pt~Y~: 0 1 0 ++1++ 1 ++0++ ++0++ ++1++, introducendo la perturbazione, Bob riceverà pt~N~ e viceversa:
pt~Y~: 0 1 0 1 1 0 0 1 ⊕ r: 0 0 0 1 0 1 1 1 ➡️ 0 1 0 0 1 1 1 0: pt~N~
pt~N~: 0 1 0 0 1 1 1 0 ⊕ r: 0 0 0 1 0 1 1 1 ➡️ 0 1 0 1 1 0 0 1: pt~Y~
***
*Form:*
![f3fa021796e95d6eb86dbdfbc67047b4.png](:/0211bf7601a6471aab73404fb558b88f)
**Risposta 4.**
Bisogna prendere la rappresentazione binaria di 100 e 200, si fa lo XOR e quella sarà la perturbazione. Risultato: 000000AC. Tutti gli altri bit devono essere lasciati inalterati quindi si lasciano a 0.
**Risposta 5.**
Rimuovo la chiave a tutti 0 in quanto la chiave con tutti 0 mi restituisce sempre un ciphertext uguale al plaintext allora per questo motivo potrei pensare di rimuoverlo.
Avendo il numero di chiavi che sono meno rispetto al numero di bit violerei il teorema di Shannon. Quindi non va rimossa come chiave anche se poi l'avversario potrebbe ottenere un testo in chiaro uguale al testo cifrato, ma non è un problema in quanto l'avversario non sa quale chiave abbiamo usato.
**Risposta 6.**
Se la chiave è costituita da tutti 0, il plaintext e il ciphertext coincidono. FARWELL è più lungo di HELLO quindi non potrebbe ottenersi in quanto viene fatto lo XOR **<span style="color: #ff0000">bitwise</span>**
***
# Stream ciphers
Quando viene mandata alla radio base la nostra voce viene digitalizzata e cifrata usando uno **<span style="color: #ff9300">stream ciphers</span>**, ovveri i cifrari a caratteri.

Il problema è che abbiamo il messaggio `p` in chiaro, poi devo costruire una chiave `k` in modo perfettamente random,==la uso una volta sola== , e faccio lo XOR. Se cambio il testo in chiaro dovrò generare una nuova chiave. 
Allora invece di generare una chiave in modo perfettamente random, potremmo inventare una operazione `G` (una funzione) che chiamo <span style="color: #007dff">GENERATORE RANDOM DI BIT (RandomBitGenerator)</span> che prende in ingresso una quantità detta seme `s` e produce in uscita una quantità `z` detto key stream. Ovvero supponiamo che riesca a inventarmi questa funzione che prende `s` come sequenza di bit in ingresso che però ha una caratteristica ovvero deve essere perfettamente random ma ha sempre una dimensione fissa, ad esempio 128 bit. Il key stream generato `z` è una sequenza di bit più lunga di `s` in modo tale da usarlo ogni volta che devo cifrare con OTP, prendendo però una porzione di `z` di volta in volta, ovvero G amplifica `s` in una sequenza molto più grande da cui prendere una porzione di bit di volta in volta per fare OTP.
![6b8048f5f4d36631c4f8344bc42a693f.png](:/12943bdfdd1b4ddc9d59b65e70251d5f)

Nello schema originario (OTP) avevamo solamente il `p`,`c` e la chiave `k` <span style="color: #ff00ff">perfettamente random</span>, adesso solo `s` deve essere <span style="color: #ff00ff">perfettamente random</span>.
`s` diventa la nuova chiave che deve rimanere segreta e posso mantenerlo per tanto tempo, in quanto il keystream è molto lungo e di volta in volta estraggo solo una piccola sequenza.

La chiave prima era perfettamente random e anche ora lo è (da `k` ad `s`). Inoltre la chiave è molto lunga quindi sembrerebbe essere tutto OK.
<span style="color: #ff7f7f">**++MA++**</span> dobbiamo ricordarci cosa dice Shannon, che dice che la chiave deve avere una dimensione pari al messaggio e deve essere perfettamente random, la chiave è `s` ma non è più della stessa lunghezza del messaggio. Avendo fatto questa scelta il numero delle chiavi sarà 2^s^ ovvero 2^128^ semi quindi il numero delle chiavi è molto minore rispetto al numero di messaggi, in quanto potrei avere messaggi di ordine più grande (un film ad esempio!) quindi questo cifrario non è più perfetto.

Bisogna adattarsi cambiando la definizione di sicurezza, trasformando ***difficult*** in ***impossible***, ma un cifrario perfetto è fattibile in teoria ma non in pratica, quindi ritornando a qualcosa di non ideale (ovvero solo ***difficult***), e questa riduzione di sicurezza la spendo con un dispositivo più facilmente usabile nella applicazione pratica.

==Da un punto di vista matematico, *difficult* vuol dire in teoria della complessità che non esiste alcun algoritmo efficiente che è in grado di violare il cifrario in tempo polinomiale, ovvero ci vorrà una grande quantità di tempo per violare il cifrario.==

La grande modifica introdotta nello schema è il componente `G`, progettandolo bene, sebbene non sia pià perfetto il cifrario sarà almeno sicuro da un punto di vista computazionale.
![49bec8665ae828be50073fd9ceb88e43.png](:/4c25fa0804ab4973bcfb809ad1b9caf5)
![27559b3237de4aadd19b5a77053d3fb9.png](:/bf412d7fd9204cbd8c2baaeba85272f8)
![4d5942aef872163e50fa8a5d2c62403f.png](:/f4483dc23eb34dc3be5acabd391a8883)

Progettare questi `G` è molto difficile.
La chiave `k` doveva essere generata in modo *truly random*. L'esempio di truly random era il lancio della moneta. In un applicazione informatica si usano ovviamente altri fenomeni, ad esempio prendendo un oscillatore elettronico che produce un onda a una certa frequenza, ma lui non la produrrà a quella frequenza precisa, queste fluttazioni sono variabili aleatorie, quindi posso usare quel fenomeno ad esempio. Quando introduco `G` non è più truly random una volta introdotto ma diventa un algoritmo, una funzione,  quindi `G` non produce numeri random infatti viene chiamato **<span style="color: #ff9300">Pseudo Random Generator</span>**. Se osservo il lancio della moneta, e l'ho lanciata 10 volte, sapere i 10 risultati di prima non influenza l'11° lancio. ++Usando un algoritmo, i bit prodotti prima invece potrebbero influenzare o potrebbero servirmi a predire quale sarà il prossimo bit++. Questo è un problema in quanto se qualcuno mi scopre un pezzo del keystream potrebbe essere in grado di prevedere anche le chiavi future.

Prendo una sequenza di bit in modo perfettamente random la `seq1` poi prendo una sequenza `seq2` generata da `G` con un certo seme. Se `G` è fatto bene le due sequenze devono essere indistinguibili. L'altra proprietà altrettanto fondamentale è che si gli do un prefisso di 20 bit, non sia in grado un attaccante di prevedere il 21° bit con una probabilità maggiore di 0.5. Se per un attaccante intuire queste due condizioni (distinguere le sequenze e prevedere il 21° bit) è un task difficile, allora `G` è fatto bene.

Quindi noi passiamo da un cifrario perfetto OTP ad un cifrario imperfetto, passiamo da una definizione di sicurezza impossibile a difficult purchè sia un vero difficult, ovvero è praticamente impossibile per l'avversario riuscire a distinguire una sequenza di bit pseudorandom da una truly random.

![9d60af566133f651b4aac0eee25e16f0.png](:/fa1d7cb53b1043c3b71d49d9b4e5ac28)

Questi generatori esistono, quelli pseudorandom sono usati in tanti campi ad esempio in tutti quei settori in cui si fa simulazione ad eventi (medicina, economia...). ==Quei generatori vanno bene per la simulazione ma non per la sicurezza in quanto sono PREVEDIBILI==. Questo perchè sebbene possano essere indistinguibili da una sequenza random, dato un prefisso riesco a predire con alta probabilità i bit che verranno generati successivamente. 

❓️Se ho un generatore esistono dei test che mi permettono di capire se il generatore è buono? <span style="color: #ff0000">SI ma</span> danno solo una condizione necessaria ++MA NON SUFFICIENTE++. Pur passando i test, un generatore potrebbe non essere sicuro.



# Hash Functions

# Digital signatures

# Keys

id: a0afb8cd1a4b4fa2aa51020fdec50c0d
parent_id: f88582bebaa24728a4a9fa616213758a
created_time: 2023-02-04T07:02:38.002Z
updated_time: 2023-02-17T13:03:03.116Z
is_conflict: 0
latitude: 0.00000000
longitude: 0.00000000
altitude: 0.0000
author: 
source_url: 
is_todo: 0
todo_due: 0
todo_completed: 0
source: joplin-desktop
source_application: net.cozic.joplin-desktop
application_data: 
order: 0
user_created_time: 2023-02-04T07:02:38.002Z
user_updated_time: 2023-02-17T13:03:03.116Z
encryption_cipher_text: 
encryption_applied: 0
markup_language: 1
is_shared: 0
share_id: 
conflict_original_id: 
master_key_id: 
type_: 1