Teoria

04/02/2023

## Introduzione
- Docente: Gianluca Dini, Pericle Perazzo
- Mail: gianluca.dini@unipi.it
- la prova finale sarà qualche domanda con risposta a scelta multipla e una piccola modifica lato codice sugli esercizi visti durante le esercitazioni con l'ing.Perazzo
* * *

Dobbiamo considerare che abbiamo un avversario che vuole attaccare il nostro sistema.
L'avversario cercherà di violare:
1. Confidenzialità
2. Integrità
3. Disponibilità

La crittografia ci permette di proteggere la confidenzialità e l'integrità dei dati.
La disponibilità si protegge in altri modi che non sono metodi crittografici.
Parleremo di <span style="color: #ff536a">crittografia applicata</span> in quanto non progetteremo algoritmi crittografici perchè inerente l'ambito matematico. Noi invece ci chiederemo come usare gli algoritmi per proteggere i dati trasmessi in rete. Ci interessa la parte applicativa. Cos'è un certificato, quali vantaggi mi da una firma digitale, etc...

***

![86c8f5828233b1aeb41f6eef238e509f.png](:/8f3627d4b1894608a7410ca2111b7bc6)


La storia ci insegna che nella maggior parte dei casi gli algoritmi crittografici "home-made" possono essere facilmente rotti. La best practice è quella di usare sempre algoritmi standard, ovvero progettati dai migliori crittografi in circolazione che sono stati attaccati e analizzati e alla fine di questo processo è stato deciso che si trattava di algoritmi sicuri e prestazionali.

La crittografia è importante in quanto nei servizi e apparati che usiamo la troviamo ovunque:
- HTTPS: Web Traffic
- Wireless Traffic: 802.11i WPA2, GSM, Bluetooth
- File cifrati su disco: EFS, TrueCrypt
- Protezione dei media: DVD(CSS) e Blu-ray (AACS)
***

## Cosa significa "Security" ❔
![689128848448f4b03620ecdbbf4d7c16.png](:/a024f293e72942c4bea59812d47d0e4a)
1. Se abbiamo una dimostrazione matematica per cui un algoritmo è sicuro quell'algoritmo è sicuro matematicamente. Esiste un algoritmo di questo tipo ma è male utilizzabile nella pratica quindi si usa molto poco. Ne vedremo un esempio dopo.

2. "Rompere quell'algoritmo matematicamente parlando o in termini di tempo è tanto difficile quanto risolvere un problema complesso". Se abbiamo un numero con 100 cifre decimali, fare la fattorizzazione è molto difficile, quindi anche usando i migliori elaboratori ci vogliono migliaia di anni. Se dimostro che rompere quell'algoritmo corrisponde a velocizzare la fattorizzazione, posso stare sicuro. Si tratta del caso della crittogradia asimmetrica.

3. Non ha dietro una dimostrazione matematica ma una prova sperimentale in cui i migliori crittografi ben equipaggiati hanno provato a romperlo ma non ci sono riusciti.

4. Scenario in cui c'è un numero enorme di chiavi di crittografia per cui potrei provarle tutte ma sono talmente tante che ci vorrebbe una quantità di tempo impraticabile. Mettendoci anche un microsecondo ci vuole una quantità di tempo inestimabile. Questa non è neanche una definizione di sicurezza.

Ci sono 4 livelli diversi di sicurezza e ogni algoritmo cerca di coprirne almeno 3. Vedremo anche in quale di questi ogni algoritmo si colloca.

## Cryptography
<span style="color: #00ff7f">È</span>: uno strumento molto utile e le fondamenta per molti meccanismi di sicurezza

<span style="color: #ff7f7f">Non è</span>: la soluzione a tutti i problemi, affidabile se implementata e usata in modo sbagliato e qualcosa da inventare e usare per conto nostro

# Primitive crittografiche

## Cyphers

### Cifrari simmetrici
![733fa3a9585401bd57d6643e5bec8b83.png](:/e8671035fd0d4708a3b602bae10dfd78)
Lo scenario di riferimento contiene due interpreti principali (**Alice** e **Bob**) che vorranno comunicare tra di loro attraverso una rete di calcolatori. Un esempio potrebbere essere che Alice usa il suo laptop per collegarsi al server di Bob. 

L'attaccante cercherà di violare la confidenzialità delle comunicazioni (++eavesdropping++) e/o alterare l'integrità della comunicazione (++tampering+). 
- <span style="color: #ff536a">eavesdropping</span>: ad esempio Alice invia la password a Bob e l'attaccante può ++**rubare**++ la password
- <span style="color: #ffcf00">tampering</span>: durante una transazione bancaria da Alice a Bob, l'attaccante ++**modifica**++ il destinatario della somma di denaro inviandoli a se stesso

Per lo meno vorremmo che il tampering sia rilevato.

Lo scenario è il medesimo del seguente:
![dc8dd5a2aef7256c296f8b87a2633454.png](:/b52c062e2269416aa69193ab0831ade7)

Alice salva un file in un repository e poi lo va a rileggere. E' come se Alice parlasse con se stessa, perchè salvare un file su un disco è come se la Alice di oggi parlasse con la Alice di domani, in quanto il file lo rileggerà nel futuro (domani, o tra un mese). Vogliamo proteggere la modifica del file.
![dcf092908949b44bfcc00c6b0c2dc20f.png](:/2b731a2df3ba4266b7d98e52a2ca65a5)

Alice e Bob dispongono di un algoritmo di crittografia che è detto <span style="color: #007dff">**cifrario** </span>costituito da una coppia di funzioni o algoritmi:
- La funzione `E` è l'algoritmo di cifratura (<span style="color: #7f77ff">encryption</span>). Prende in ingresso una chiave `K` che è un segreto da immaginare come una sequenza di bit (es: 010100010) che tipicamente ad oggi è dell'ordine di 128 bit. Come si genera una chiave `k` in modo intuitivo? Prendo una "moneta", lanciandola, in base al risultato stabilisco il valore dei bit, ovvero se esce testa ==> 1, se esce croce ==> 0, la lancio 128 volte e segno i 128 valori. Questa funzione usando i parametri di input mi restituisce il crittogramma `c` che è la cifratura del testo in chiaro da cifrare `p`. Questo `c` verrà inviato sulla rete e noi ipotizzeremo che il nostro avversario sia così bravo da intercettare `c`. Questo è il threat model d'esempio.

- La funzione `D` è l'algoritmo di decifratura (<span style="color: #ff536a">decryption</span>). `c` arriverà a Bob che prende in ingresso anche la stessa chiave `k` e l'algoritmo `D` restituirà il messaggio originario inviato da Alice.

Sia Alice che Bob avranno la loro coppia identica di funzioni `D` ed `E` (es. librerie python o chip elettronici sulla scheda di rete). La chiave `k` è un segreto condiviso tra Alice e Bob e non deve essere pubblico. La sicurezza di questo sistema che protegge la confidenzialità della comunicazione si basa sulla complessità di `k`.

Se chiunque conosce la chiave `k` ovvero la sequenza esatta di 128 bit ad esempio, prenderebbe `c`, userebbe l'algoritmo `D` che è pubblico, e otterrebbe `p`. 

❓️Come fanno Alice e Bob ad avere un segreto condiviso `k`

Potrebbero incontrarsi  e scambiarselo al bar, ma funziona meno bene questa soluzione se il client e il server si trovano in locazioni geografiche molto distanti. Come lo stabiliscono è un problema e lo vedremo più avanti. Alice da casa sua potrebbe lanciare la moneta e definire `k` e inviarla a Bob ma mandandola in chiaro l'avversario la intercetterebbe e non sarebbe più sicura la comunicazione. Per mandarla in rete in modo protetto dovrei cifrarla ma per farlo ci vorrebbe un altra chiave `K`<sub>`1`</sub> e il problema si ripeterebbe. Si può interrompere o con metodi OFFLINE (si incontrano al bar o usando un altro mezzo di comunicazione, la lettera postale con dentro il pin che la banca ci invia a casa è un esempio di mezzo di comunicazione alternativo utilizzato nella realtà) oppure ONLINE ovvero raggiungere un segreto condiviso attraverso la rete stessa definita come insicura, ad esempio il TLS mi permette di raggiungere questo obiettivo ma per farlo è necessaria la crittografia a chiave pubblica.

Per ora il nostro assunto è:
✅ Alice e Bob hanno un segreto `k` condiviso
✅ L'attaccante conosce gli algoritmi utilizzati `D` ed  `E`
✅ L'attaccante può intercettare `c`

![1ca21be2fa8de17837b6d9c7a75ed222.png](:/739a0763d5fd460a807ac70d15543bda)

Per far si che tutta la sicurezza sia concentrata in `k` e non nel resto è necessario che dato `c` deve essere difficile determinare `p` senza conoscere la chiave `k`. Di tutte le funzioni `D` ed `E` che posso inventarmi devo trovare quelle per cui deve essere molto difficile trovare `p` non conoscendo `k` e avendo solo `c`. Questa proprietà dipende dal fatto che il mio avversario può intercettare qualsiasi messaggio. Se il mio sistema è sicuro deve esserlo per ogni comunicazione. Dati `c` e `p` deve essere inoltre difficile ottenere la chiave `k`, a meno che non sia usata una volta sola (questa clausola verrà compresa più avanti quando parleremo del cifrario di Vernam):
![8f1241c4a0ff80296716af6b9182696a.png](:/baa379f0f77e4a61ab53d4f263319e3a)
L'avversario cercherà di violare almeno una di queste 2 proprietà tramite la <span style="color: #ffc86c">crittoanalisi</span>, ovvero *lo studio delle tecniche matematiche per rompere l'algoritmo crittografico ovvero violare queste 2 proprietà*. Le ipotesi sono: l'avversario ha accesso ai dati trasmessi in forma cifrata ovvero intercettare qualsiasi cosa e l'altra è l'ipotesi di Kerckhoffs ovvero l'avversario conosce tutti i dettagli degli algoritmi di cifratura in quanto pubblicamente reperibili.

***
📖
In crittografia, il principio di Kerckhoffs (conosciuto anche come legge di Kerckhoffs), enunciato per la prima volta da Auguste Kerckhoffs alla fine del 1880, afferma che un crittosistema deve essere sicuro anche se il suo funzionamento è di pubblico dominio, con l'eccezione della chiave.
***

Tenere segreti gli algoritmi `E` e `D` storicamente non ha mai funzionato: la Security trough Obscurity (vedi film ENIGMA). In genere `E` e `D` sono scritti nel firmware delle schede elettroniche, se fossero sconosciute a tutti tranne che al produttore e dovessero essere venir rotte da un attaccante, il produttore dovrebbe ritirare tutte le schede elettroniche dal mercato, cambiare `E` e `D` e ridarle ai propri clienti. Cosa diversa se le funzioni hanno passato una fase di criptoanalisi condivisa a livello globale da diverse istituzioni e standardizzata e dunque conosciuta da tutti.

#### 👥Esempi di cifrari simmetrici👥
<span style="color: #000000"><span style="background-color: #ffc8ab">Algoritmo a sostituzione monoalfabetica</span></span>
![137e4379c644c4f71becbe87672f526e.png](:/faf4c73e6a1a431c92dff17d45b99c6a)
Nell'esempio, `P`<sup>`'`</sup>  contiene le lettere raggruppate a gruppi di 5 solo per evitare di mappare le lettere 1:1 e rendere l'attacco più facile del previsto.

L'avversario in rete intercetta `C` e vorrebbe ricavare `P`. L'avversario potrebbe iniziare a ragionare sui caratteri ma quello che sicuramente può fare l'avversario è eseguire un' <span style="color: #ff7f7f">attacco esaustivo alle chiavi</span> o anche detto <span style="color: #ff7f7f">attacco a forza bruta o brute-force</span>, fin quando non ottiene un messaggio avente un senso compiuto. Se lui fa un attacco a forza bruta deve provare tutte le possibili permutazioni, con `n` elementi le permutazioni sono `n!`.
In questo caso 26! è circa 4 x10<sup>26</sup> e se anche ci mettesse un microsecondo per ogni permutazione ci vorrebbe troppo tempo. Questo significa che è **DIFFICILE**. Visto così questo algoritmo sembrerebbe molto sicuro, perchè ci vuole molto tempo per un attacco a forza bruta. 

Le lettere però non sono tutte equiprobabili nei testi scritti. Nella lingua inglese la lettera che appare più frequentemente è la lettera 'E' 'T' ed 'A'. Se la lettera più frequente nella lingua inglese è la 'E', ma con l'algoritmo di crittografia dell'esempio io la trasformo in 'S', troverò molte 'S' ed è molto probabile che corrisponda alla lettera 'E'.
![06cfc3bf15a5b2f363d689126a3398c2.png](:/ee8e9ebdcbce418693145e6974d1c204)
Si può ragionare anche per coppie di lettere (es. TH in inglese è molto frequente).
Sfruttando le statistiche del linguaggio è possibile crittoanalizzare il testo cifrato e trovare la chiave.

***
**11/02/2023**

L'altra volta abbiamo fatto alcune considerazioni generali e abbiamo visto un primo cifrario ovvero quello a sostituzione monoalfabetica. Abbiamo visto in un caso semplice cosa vuol dire attaccare un cifrario. 

# Perfect cyphers
Un cifrario perfetto esiste, è molto semplice da realizzare, è stato realizzato in pratica ma capiremo perchè non lo usiamo tutti i giorni.

❔Un cifrario perfetto cosa vuol dire?
Shannon nel **1949** diede una definizione matematica, in quegli anni di guerra esisteva Turing e al tempo stesso in America c'era Shannon con Von Neuman: 
- *"Un cifrario è perfetto se non rivela alcuna informazione sul testo in chiaro"*
Se la coppia di algoritmi `E` e `D` vuol dire che l'avversario intercetterà tutto il testo cifrato possibile ma non riuscirà ad ottenere alcuna informazione riguardo il testo in chiaro.

- Inoltre se riusciamo a costruire un cifrario perfetto, non ci interessa nemmeno la ++potenza computazionale<span style="color: #ff0000"></span>++ dell'avversario, ovvero si può ipotizzare che si trovi in una condizione di capacità di calcolo infinita.
- 💡<span style="color: #000000"><span style="background-color: #ffff00">Teorema di Shannon</span></span>
Se riuscissimo a costruire un cifrario perfetto , si può dimostrare che il numero delle chiavi deve essere maggiore o uguale del numero dei messaggi.
![3ad0971d19c1d743cf86f1635119fbae.png](:/318d46aa53a143d1a31700fbdaaf9395)

## One Time Pad
Il cifrario perfetto esiste e si chiama **One Time Pad** (Vernam cipher, 1917).

Supponiamo che il testo in chiaro sia sostanzialmente una sequenza di bit. Ogni casella è un bit e può contenere o il bit 0 il bit 1. Chiaramente se l'avversario la intecetta si troverà con la sequenza di bit, e magari se conoscesse a priori che Alice e Bob si stanno scambiando un PDF potrà interpretare la sequenza come PDF, ovvero l'avversario non esegue mai l'attacco alla cieca ma parte già con una conoscenza pregressa. Il cifrario di Vernam prevede di prendere una chiave `K` che ha tanti bit quanti sono i bit del messaggio. ⚠️ ==**La chiave viene costruita in modo randomico**== ⚠️ . A questo punto viene eseguita l'operazione di **OR ESCLUSIVO (XOR)** bit a bit. Ovvero per ogni coppia di bit partendo dalla prima coppia, usando l'operazione XOR, produco il cipher text.
![38ecf07e7edb3645414cbcb511c888fa.png](:/862ee5dbccdf4f07bd2194cbde877c51)
Le operazioni bit a bit sono estremamente efficienti e veloci. Si tratta di un operazione molto semplice, veloce e poco costosa computazionalmente parlando, quindi da un punto di vista implementativo è ideale.

⚠️ **XOR**
Si tratta di un operazione logica binaria. Per definizione se i due bit sono diversi il risultato è 1 altrimenti se sono uguali ritorna 0.
|  p |  k | c |
|--- |--- |---|
| 0  | 0  | 0 | 
| 0  | 1  | 1 |
| 1  | 0  | 1 | 
| 1  | 1  | 0 |
⚠️ 

![a91494dd73a6529a9c3a3d1ef2026a2b.png](:/03133d88411845ef89aec9658e8f0799)

Si può dimostrare che conoscendo il testo cifrato `c`, è possibile decriptare riapplicando lo XOR con la chiave `k` in possesso.

Possiamo dimostrare che se la chiave è ++<span style="color: #ff6835">perfettamente random</span>++, allora il cifrario di Vernam è perfetto. 
![a2570c3e88f78baac3e6d7d514b7c920.png](:/a42bf7f5e282412e890a39624676b98e)

*Esempio del perchè il cifrario è perfetto:*
![ed128289c2aba60e3e4f1f87c6e2e692.png](:/561c3a881e2f49029320fa09f31a4d20)

Scenario: james bond deve andare in missione in nazione straniera, quindi il suo capo manda un messsaggio `m` all'agente di supporto in cui dice "supporta james bond". La chiave che viene generata è `k` ma non sto usando i bit ma i caratteri. Qui c'è una complicazione...

⚠️ Lo XOR è una somma a singolo bit in base 2, qui stiamo facendo una somma in singola cifra in base 26. Il concetto è che se prendiamo le prime lettere di `m` e `k` ovvero 'S' e 'W', usando l'alfabeto inglese che ha 26 caratteri, alla A associo il valore 0, B il valore 1 ... alla Z il valore 25. S + W mi porta sulla lettera O in quanto essendo modulare in base 26 è ciclico su 26 caratteri posssibli, è come se l'alfabeto fosse circolare.
![76406562fa9044aa284d5ba7d046a313.png](:/9d11429a82d74badb7f48feae90a0f69)
Si può dimostrare che questo corrisponde a fare lo XOR.
⚠️

`c` è il messaggio che viene trasmesso in rete. Questo viene intercettato dall'avversario il quale vuol cercare di capirci qualcosa, ma essendo perfetto non riesce. Può però provare un attacco a forza bruta ovvero provare tutte le possibili chiavi. Avendo un messaggio di 16 caratteri con un alfabeto di 26 caratteri avremmo **26^16^** possibili chiavi.

Pur provandole tutte lui otterrà da ogni possibile chiave un plaintext, ovvero tutti i possibili messaggi su 16 caratteri. Tra questi messaggi ci sarà anche quello che sta cercando ma ce ne sarà anche qualcuno che ha senso compiuto ma non è quello originale mandato, ad esempio:
"CAPTURE JAMES BOND".

<span style="color: #ff6835">Non si usa nella pratica per i seguenti motivi</span>:
![44296a9a5308cb86ffc35ae20ea8f14f.png](:/96bc437c4db4415db230b78a8d5dd98b)
- **<span style="color: #ff0000">la chiave deve essere lunga quanto il messaggio</span>**, per messaggi lunghi diventa impossibile (1gigabit di film da cifrare diventa molto scomodo da un punto di vista pratico, in quanto sarà necessaria una chiave da 1gigabit)
- <span style="color: #ff0000">**la chiave può essere usata una volta sola**</span>, perchè si può dimostrare che l'avversario dai due testi cifrati usando la stessa chiave potrebbe ottenere informazioni riguardo la chiave stessa
- se dispongo del testo cifrato e del testo in chiaro,<span style="color: #ff0000"> **ricavare la chiave è molto semplice**</span>
- **<span style="color: #ff0000">il cifrario è malleabile</span>**: se usassi la chiave una volta non ci sono problemi. L'altro obiettivo è il tampering, ovvero l'avversario potrebbe modificare il messaggio, il problema del OTP è che mentre è sicuro rispetto all'eavesdropping, non ho alcuna garazia sul tampering, ed ancora peggio è ++MALLEABILE++: *ovvero delle modifiche al cipher text da parte dell'avversario non sono rilevabili e inoltre l'avversario riesce ad avere un controllo delle modifiche in modo tale che il ricevente decifri quello che l'avversario vuole*.
![80efcfb49a7c266128d5f6086fb3bf74.png](:/3ac9c4aa25cd423fb848233f3f13fe44)


❗️==I cifrari non sono forti rispetto all'integrità perchè sono progettati per fare altro (confidenzialità). Per questo motivo parleremo di funzioni di hash e firme digitali.==

Come fa l'avversario a sapere che deve mettere esattamente i caratteri al posto di quelli? 
Chiaramente l'esempio è didattico, ma l'avversario potenzialmente può conoscere tutto eccetto le chiavi, quindi potrebbe conoscere la struttura del messaggio di massima, ovver la prima parte è il comando, la seconda parte è la quantità di denaro, la terza parte è la valuta e la quarte parte è il destinatario:
![b52cd59c8e1cdcffc82e42da5d672d6c.png](:/d5293579e5b945e586f93ff572e57b79)

La dimostrazione matematica di malleabilità: 

`r` è la perturbazione introdotta dall'avversario, si può dimostrare che lato ricevente si riceve il testo in chiaro XOR la perturbazione, che non viene rilevata ed ha un impatto prevedibile. Lo XOR esclusivo tra `r` e il testo cifrato mi si propaga sul testo in chiaro. Inoltre `r` è totalmente indipendente dalla chiave `k`.
![4d9fd7542e3340bb7069594f4eb25398.png](:/0af4a13b3b1c47e0acf63dbc99d79833)

Esercizio:
![d62f5f7d0b8f6dbc7d2cd5c62d69ef66.png](:/e8e369e2a6634f41b498c3c40534d4c8)
![8f2cef424b1179b775069b83786a472c.png](:/e291ee05c61f49f1ab06e0efdd03b317)

Trovo le differenze in bit tra pt~Y~ e pt~N~:
pt~Y~: 0 1 0 ++1++ 1 ++0++ ++0++ ++1++
pt~N~: 0 1 0 ++0++ 1 ++1++ ++1++ ++0++

e noto che sono opposti tra di loro (quelli sottolineati). Per invertire un bit basta fare: bit_che_si_vuole_invertire ⊕ 1 dunque la perturbazione r sarà costituita dagli 1 in corrispondenza dei bit che voglio far flippare e degli 0 in corrispondenza di quelli che voglio lasciare intatti:
r : <span style="color: #0055ee">0</span> <span style="color: #0055ee">0</span> <span style="color: #0055ee">0</span> <span style="color: #ff0000">1</span> <span style="color: #0055ee">0</span> <span style="color: #ff0000">1</span> <span style="color: #ff0000">1</span> <span style="color: #ff0000">1</span>

Se la risposta di Alice è pt~Y~: 0 1 0 ++1++ 1 ++0++ ++0++ ++1++, introducendo la perturbazione, Bob riceverà pt~N~ e viceversa:
pt~Y~: 0 1 0 1 1 0 0 1 ⊕ r: 0 0 0 1 0 1 1 1 ➡️ 0 1 0 0 1 1 1 0: pt~N~
pt~N~: 0 1 0 0 1 1 1 0 ⊕ r: 0 0 0 1 0 1 1 1 ➡️ 0 1 0 1 1 0 0 1: pt~Y~
***
*Form:*
![f3fa021796e95d6eb86dbdfbc67047b4.png](:/0211bf7601a6471aab73404fb558b88f)
**Risposta 4.**
Bisogna prendere la rappresentazione binaria di 100 e 200, si fa lo XOR e quella sarà la perturbazione. Risultato: 000000AC. Tutti gli altri bit devono essere lasciati inalterati quindi si lasciano a 0.
**Risposta 5.**
Rimuovo la chiave a tutti 0 in quanto la chiave con tutti 0 mi restituisce sempre un ciphertext uguale al plaintext allora per questo motivo potrei pensare di rimuoverlo.
Avendo il numero di chiavi che sono meno rispetto al numero di bit violerei il teorema di Shannon. Quindi non va rimossa come chiave anche se poi l'avversario potrebbe ottenere un testo in chiaro uguale al testo cifrato, ma non è un problema in quanto l'avversario non sa quale chiave abbiamo usato.
**Risposta 6.**
Se la chiave è costituita da tutti 0, il plaintext e il ciphertext coincidono. FARWELL è più lungo di HELLO quindi non potrebbe ottenersi in quanto viene fatto lo XOR **<span style="color: #ff0000">bitwise</span>**
***
# Stream ciphers
Quando viene mandata alla radio base la nostra voce viene digitalizzata e cifrata usando uno **<span style="color: #ff9300">stream ciphers</span>**, ovveri i cifrari a caratteri.

Il problema è che abbiamo il messaggio `p` in chiaro, poi devo costruire una chiave `k` in modo perfettamente random,==la uso una volta sola== , e faccio lo XOR. Se cambio il testo in chiaro dovrò generare una nuova chiave. 
Allora invece di generare una chiave in modo perfettamente random, potremmo inventare una operazione `G` (una funzione) che chiamo <span style="color: #007dff">GENERATORE RANDOM DI BIT (RandomBitGenerator)</span> che prende in ingresso una quantità detta seme `s` e produce in uscita una quantità `z` detto key stream. Ovvero supponiamo che riesca a inventarmi questa funzione che prende `s` come sequenza di bit in ingresso che però ha una caratteristica ovvero deve essere perfettamente random ma ha sempre una dimensione fissa, ad esempio 128 bit. Il key stream generato `z` è una sequenza di bit più lunga di `s` in modo tale da usarlo ogni volta che devo cifrare con OTP, prendendo però una porzione di `z` di volta in volta, ovvero G amplifica `s` in una sequenza molto più grande da cui prendere una porzione di bit di volta in volta per fare OTP.
![6b8048f5f4d36631c4f8344bc42a693f.png](:/12943bdfdd1b4ddc9d59b65e70251d5f)

Nello schema originario (OTP) avevamo solamente il `p`,`c` e la chiave `k` <span style="color: #ff00ff">perfettamente random</span>, adesso solo `s` deve essere <span style="color: #ff00ff">perfettamente random</span>.
`s` diventa la nuova chiave che deve rimanere segreta e posso mantenerlo per tanto tempo, in quanto il keystream è molto lungo e di volta in volta estraggo solo una piccola sequenza.

La chiave prima era perfettamente random e anche ora lo è (da `k` ad `s`). Inoltre la chiave è molto lunga quindi sembrerebbe essere tutto OK.
<span style="color: #ff7f7f">**++MA++**</span> dobbiamo ricordarci cosa dice Shannon, che dice che la chiave deve avere una dimensione pari al messaggio e deve essere perfettamente random, la chiave è `s` ma non è più della stessa lunghezza del messaggio. Avendo fatto questa scelta il numero delle chiavi sarà 2^s^ ovvero 2^128^ semi quindi il numero delle chiavi è molto minore rispetto al numero di messaggi, in quanto potrei avere messaggi di ordine più grande (un film ad esempio!) quindi questo cifrario non è più perfetto.

Bisogna adattarsi cambiando la definizione di sicurezza, trasformando ***difficult*** in ***impossible***, ma un cifrario perfetto è fattibile in teoria ma non in pratica, quindi ritornando a qualcosa di non ideale (ovvero solo ***difficult***), e questa riduzione di sicurezza la spendo con un dispositivo più facilmente usabile nella applicazione pratica.

==Da un punto di vista matematico, *difficult* vuol dire in teoria della complessità che non esiste alcun algoritmo efficiente che è in grado di violare il cifrario in tempo polinomiale, ovvero ci vorrà una grande quantità di tempo per violare il cifrario.==

La grande modifica introdotta nello schema è il componente `G`, progettandolo bene, sebbene non sia pià perfetto il cifrario sarà almeno sicuro da un punto di vista computazionale.
![49bec8665ae828be50073fd9ceb88e43.png](:/4c25fa0804ab4973bcfb809ad1b9caf5)
![27559b3237de4aadd19b5a77053d3fb9.png](:/bf412d7fd9204cbd8c2baaeba85272f8)
![4d5942aef872163e50fa8a5d2c62403f.png](:/f4483dc23eb34dc3be5acabd391a8883)

Progettare questi `G` è molto difficile.
La chiave `k` doveva essere generata in modo *truly random*. L'esempio di truly random era il lancio della moneta. In un applicazione informatica si usano ovviamente altri fenomeni, ad esempio prendendo un oscillatore elettronico che produce un onda a una certa frequenza, ma lui non la produrrà a quella frequenza precisa, queste fluttazioni sono variabili aleatorie, quindi posso usare quel fenomeno ad esempio. Quando introduco `G` non è più truly random una volta introdotto ma diventa un algoritmo, una funzione,  quindi `G` non produce numeri random infatti viene chiamato **<span style="color: #ff9300">Pseudo Random Generator</span>**. Se osservo il lancio della moneta, e l'ho lanciata 10 volte, sapere i 10 risultati di prima non influenza l'11° lancio. ++Usando un algoritmo, i bit prodotti prima invece potrebbero influenzare o potrebbero servirmi a predire quale sarà il prossimo bit++. Questo è un problema in quanto se qualcuno mi scopre un pezzo del keystream potrebbe essere in grado di prevedere anche le chiavi future.

Prendo una sequenza di bit in modo perfettamente random la `seq1` poi prendo una sequenza `seq2` generata da `G` con un certo seme. Se `G` è fatto bene le due sequenze devono essere indistinguibili. L'altra proprietà altrettanto fondamentale è che si gli do un prefisso di 20 bit, non sia in grado un attaccante di prevedere il 21° bit con una probabilità maggiore di 0.5. Se per un attaccante intuire queste due condizioni (distinguere le sequenze e prevedere il 21° bit) è un task difficile, allora `G` è fatto bene.

Quindi noi passiamo da un cifrario perfetto OTP ad un cifrario imperfetto, passiamo da una definizione di sicurezza impossibile a difficult purchè sia un vero difficult, ovvero è praticamente impossibile per l'avversario riuscire a distinguire una sequenza di bit pseudorandom da una truly random.

❓️Perchè deve essere impredicibile?
Supponiamo di avere a disposizione del testo cifrato `c` e supponiamo che l'attaccante conosca del testo in chiaro un prefisso (quello in rosso all'inizio). Questa situazione nella realtà è probabile in quanto molto spesso i messaggi inviati sulla rete usano degli header sempre simili per trasportare dei metadati utili alla comunicazione ma che non hanno alcun payload. L'attacante potrebbe fare lo XOR tra il prefisso del messaggio e il prefisso del testo cifrato, ottenendo un "prefisso" della chiave. Se il generatore fosse prevedibile, da questo prefisso iniziale della chiave potrei iniziare ad indovinare i bit che vengono dopo con alta probabilità, dunque potrei andare a ricavare anche il pezzo di testo in chiaro che mi manca.
==Ecco perchè `G` deve essere **unpredictable**!==:
![50fce33fa0a67b9d4ad12088a6dc7a08.png](:/4ada4b65e3c3427184de2b762a040dc5)


![9d60af566133f651b4aac0eee25e16f0.png](:/fa1d7cb53b1043c3b71d49d9b4e5ac28)

Questi generatori esistono, quelli pseudorandom sono usati in tanti campi ad esempio in tutti quei settori in cui si fa simulazione ad eventi (medicina, economia...). ==Quei generatori vanno bene per la simulazione ma non per la sicurezza in quanto sono PREVEDIBILI==. Questo perchè sebbene possano essere indistinguibili da una sequenza random, dato un prefisso riesco a predire con alta probabilità i bit che verranno generati successivamente. 

❓️Se ho un generatore esistono dei test che mi permettono di capire se il generatore è buono? <span style="color: #ff0000">SI ma</span> danno solo una condizione necessaria ++MA NON SUFFICIENTE++. Pur passando i test, un generatore potrebbe non essere sicuro.

***
**18/02/2023**
La sicurezza computazionale è una sicurezza imperfetta in quanto non è definita alla Shannon, in linea di massima è possibile ma magari vuole troppo tempo o una quantità elevata di risorse e denaro. E' definita come *il livello percepito di computazione richiesta per difendersi da un attacco, basato sul **miglior attacco conosciuto** e sul **tipo di avversario ipotizzato**.*
![10bf472474b1b6c9f3de2f58c6584fe9.png](:/f01ba70f17ff4e0cbac378e407fec25c)
Le parole evidenziate sono importanti in quanto non siamo nel caso di OTP in cui la sicurezza è perfetta e dunque non mi interessa chi ho di fronte, nessuno di loro è in grado di ottenere informazioni dal testo cifrato. Nelle condizioni in cui operiamo ora siamo in un mondo di sicurezza computazionale.
❓️Devo difendermi da che tipo di avversario? Perchè cambia l'expertise e il budget del mio avversario.
❓️Qual'è il miglior attacco conosciuto ad oggi? Ad oggi non esiste un algoritmo ad esempio che permette di distinguere un generatore random da uno non random, ma se domani questa condizione dovesse cambiare, vuol dire che questo generatore che veniva percepito come sicuro deve essere cambiato.

<span style="color: #0083ff">**Esempio: 802.11b WEP**</span>

![7bb9fa420330836dfa687c2555780250.png](:/4c30c47e76c446ea84dacaefdce6d5c0)
Inizialmente l'esigenza era quella di proteggere tutte le comunicazioni tra il client e l'access point, in quanto la comunicazione avviene in aria e quindi il mio avversario potrebbe ascoltarla. **WEP** è un **cifrario a caratteri**, che cercava di proteggere il messaggio `m`. `CRC(m)` è il codice di ridondanza per il recupero degli errori. Inoltre viene generato un seme dal quale si genera il `Keystream`. Il seme `s` è fatto da due quantità:
- <span style="color: #ff0000">la chiave</span>: la password del wifi dopo alcune manipolazioni in qualche modo diventava la chiave usata. La dimensione è di 104 bit.
- <span style="color: #ff0000">IV</span>: **il vettore di inizializzazione** è un numero che potrebbe essere creato tramite un contatore. L'idea è che per ogni nuovo messaggio `m` ci vuole un nuovo `IV`. La dimensione è di 24 bit.

Sul lato ricevitore, si riceve il cyphertext, dunque per trovare il testo `m` dovrà fare lo XOR tra `c` e PRG( IV || K ).
L'IV viene trovato all'inizio del messaggio ricevuto, spedito in chiaro.

Avendo 24 bit, posso andare a rappresentare tutti gli interi che vanno da 0 a 2^24^ - 1. In tutto ho <span style="color: #ff78ff">circa 16 milioni</span> di vettori di inizializzazione. Dato che IV viene creato progressivamente e che il keystream dipende dal IV, significa che avrò al massimo 16 milioni di keystream. Avendo un IV per ogni messaggio, una volta trasmessi 16 milioni di messaggi, inizierò a generare nuovamente gli stessi keystream perchè gli IV ricominciano dal primo. Se riutilizzo il Keystream, l'avversario vede che viene riutilizzato (vede riapparire lo stesso IV più volte), dunque inizia a fare quella serie di attacchi mirati ai keystream ripetuti.

⚠️Problemi⚠️:
- Il problema è che 24 bit è piccolo, dunque ++la ripetizione si verifica abbastanza presto++ con una quantità di traffico abbastanza piccolo (pochi milioni di messaggi)
- Il numero 24 è scritto nella standard dunque come produttore di schede di rete devo necessariamente rilasciare prodotti che siano standardizzati, dunque come produttore sono costretto a usare un IV da 24 bit.
- Pensando al client, esso all'accensione riparte a generare l'IV dal valore 0, dunque per l'attaccante basterà mettersi in ascolto all'accensione, in quanto tutti i messaggi all'accensione del client partiranno sempre con lo stesso IV.
![e97e38d3b48c85a4ba03ac30d7beb1fa.png](:/580cd1832dac4574bb7b5bfc1714e530)

Questo è un esempio di protocollo <span style="color: #ff0000">INSICURO</span> costruito con componenti <span style="color: #ff0000">SICURI</span>.

Lo pseudo random generator usato è l'**RC4**, che è debole rispetto all'**<span style="color: #7f77ff">attacco alle related keys</span>**!
![2b083eee67d15235fe5d40173e06b4d6.png](:/e365607346d9436baa42af3bf5d1c07f)

Dato che la chiave è fissa e il IV è progressivo, il seme che veniva generato aveva questa forma:
1 || K
2 || K
3 || K
...
queste chiavi sono correlate con K, dunque in questa situazione il generatore non è così impredicibile.

In questo caso, non potendo sostituire WEP, hanno rilasciato delle fix software realizzate sul firmware della scheda tramite i driver della scheda, per ottenere la versione più sicura (WPA).

*Form*
![33ad4699fe7b798485f63e643daa3b26.png](:/4d15fd02e0094d29a42ff95ef6af3835)



# Block Cyphers

Il cifrario a caratteri che abbiamo visto come evoluzione di OTP è come se cifrasse un bit alla volta. Nel caso dei cifrari a blocchi invece viene preso un blocco di bit (ad esempio 64 bit) di testo in chiaro che viene cifrato ogni volta. ++Non viene più fatta la cifratura un bit alla volta++. 
![35a2f97290aeb0006c413f82c12497ec.png](:/d6462782e802403bb6800e9bbd08f18a)
{0,1}^n^ significa che vengono considerate sequenze di `n` bit. Dunque se in ingresso ho  `n` li avrò anche in uscita, usando una chiave `k`. Da un punto di vista matematico, `E` definisce una permutazione. La cosa interessante è che di questi algoritmi di encryption `E` ne posso avere tanti quant'è la lunghezza delle chiavi `k`. 
Ovvero avrò l'algoritmo E~0~ associato a k~0~, E~1~ associato a k~1~ etc...
Ogni algoritmo genera permutazioni diverse ed Alice e Bob dovranno mettersi d'accordo su quale algoritmo usare. Dunque per evitare che l'attaccante inferisca l'`E` tramite brute-force chi comunica dovrà usare un numero elevato di `k`.  Ad oggi vengono usate chiavi da almeno 128 bit.

**<span style="color: #0083ff">*Esempio di block cyphers: DES*</span>**
La chiave è rappresentata in formato esadecimale, con 56 bit (chiave molto corta!) infatti DES non è più sicuro al giorno d'oggi, ma lo è stato per molti anni (fino agli 90 circa) grazie al fatto che fosse "*difficult*" ricavare la chiave tramite brute-force.
![a213cd46319819f5cfa2d7f31b2c7fef.png](:/94198fc999674ef99cd590670ae66d83)
==Il numero delle chiavi deve essere molto grande per rendere un cifrario a blocchi "**sicuro alla Shannon**" dunque è impossibile nella pratica!:==
![953b5a9064891fc472e1ce0b1bd59aa2.png](:/4cc72e4dde3743cfa60ccf0cd7ce945c)

Esistono alcune caratteristiche di un cifrario che interessano:
- <span style="color: #ff9300">**n**</span>: la dimensione del blocco, quanti bit alla volta andiamo a cifrare
- <span style="color: #ffcf00">**k**</span>: la dimensione della chiave

![e02f8385e8a6470945964bdd7b490b56.png](:/a89a96162f674beca16980fabfad8c88)
Lo standard ad oggi in vigore è AES-128, è abbastanza probabile che in futuro si migrerà sui 256 bit di chiave.

Di ogni algoritmo, per esempio DES nell'immagine in basso, ci interessa una tabella che mi dica quale è il best-known attack, ovvero il migliore attacco conosciuto al momento e quali sono e quante sono le risorse necessarie per fare quell'attacco.
![16f9946a0ffa60c1de88d56eaa223714.png](:/cb4ec53a631f4e35ae47a477dce0de69)

Ad esempio la ricerca esaustiva della chiave prevede di prendere, per ogni possibile chiave, il testo in chiaro p e cifrarlo con `k`. Se ottengo lo stesso `c` intercettato sulla rete, ho trovato la chiave. Questa metodologia in caso di cifrario perfetto non servirebbe, ma essendo DES non perfetto può funzionare.
Questo attacco mi costa solamente per il numero di chiavi, in quanto dovrò provare 2^56^ chiavi. Statisticamente posso essere sfortunato (**dunque provarle tutte e 2^56^**) oppure fortunato (**trovarla al primo colpo**), dunque essendo le probabilità al 50% dovrò provare 2^56^/2 volte = 2^55^. Questo numero ++AD OGGI++ è troppo basso, ovvero compiere 2^55^ cicli si riescono a completare in poco tempo e con risorse alla portata di quasi tutti ed è il motivo per cui DES non viene più considerato uno standard di sicurezza per le applicazioni moderne.

L'attacco di crittoanalisi differenziale è un attacco che per implementarlo in questo caso ho bisogno di 2^47^ coppie `p` e `c`. Inoltre la memoria di storage di cui ho bisogno in questo caso non è stimata in quanto non è particolarmente interessante, ma dovrò fare 2^47^ cicli for.  Ecco perchè questo tipo di attacco non è stato mai messo in pratica nella realtà contro DES in quanto il numero di coppie necessarie da procurarsi è altissimo, in quanto poi ognuna di queste chiavi dovrà essere memorizzata.

### Storia del DES
DES viene standardizzato nel **1978**, e prima di essere standardizzato il NIST lanciò una competizione per chiedere alla comunità accademica e non solo di poter proporre il proprio algoritmo di cifratura. Questa infatti fu anche la prima volta nella storia che un algoritmo di crittografia veniva concepito in ambito civile e non ambito militare. Questo perchè nei primi anni 70 cominciava ad affermarsi Internet e ci si rese conto che bisognava andare a crittografare le transazioni economico finanziarie. La competizione venne vinta da **IBM** con il proprio algoritmo **Lucipher**. **DES** ha un blocco a 64 bit e una chiave a 56 bit. **Lucipher** nella sua versione originaria aveva un blocco a 64 bit e una chiave a 64 bit. **<span style="color: #ff3000">La chiave nel caso del DES è più piccola</span>**. Le modifiche richieste dalla **National Security Agency** sono state di ridurre la chiave e modificare il funzionamento dell'algoritmo. Le motivazioni dietro queste richieste rimangono ad oggi ancora sconosciute. Nel **1980** due ricercatori inventono l'algoritmo di crittoanalisi differenziale. Quando NSA richiede quelle modifiche, tutti pensano che siano state richieste apposta affinchè l'NSA potesse romperlo in qualsiasi momento. L'NSA probabilmente conosceva già la crittoanalisi differenziale nel 1980, dunque Lucipher nel 1978 sarebbe potuto essere vulnerabile ad un attacco di tipo crittonalisi differenziale ma al tempo stesso richiedendo una riduzione della lunghezza della chiave avrebbe permesso, a patto di avere grandi risorse (che solo l'NSA o enti governativi avevano) di poter rompere in qualsiasi momento il DES. Hanno dunque rinforzato l'algoritmo per il pubblico ma lo hanno reso vulnerabile solo per entità molto potenti computazionalmente come il governo americano.

Ci si rese conto che con 56 bit di chiave, DES non era più adeguato, allora venne lanciato intorno agli anni 90 un nuovo concorso per standardizzare un nuovo algoritmo di cifratura. Nel frattempo, come soluzione temporanea, fu deciso di usare la cifratura multipla...

## Cifratura multipla
Venne lanciata la DES challenge, in cui si rese pubblica una parte del testo in chiaro e la challenge consisteva nel trovare il restante testo in chiaro.
![1b6d03f4944983de8511e4af85d8c118.png](:/13e325eb94124391881654e948a1ca4d)
Ci furono vari tentativi, partendo da tentativi puramente software nel 1997 in cui si prese una parte delle chiavi e si distribuì su un certo numero di macchine su internet disponibili a partecipare a questo progetto. Ci vollero circa 3 mesi per trovare tutto il testo in chiaro. Fin quando nel 2006 ci fu l'esperimento di COPACABANA in cui in 7 giorni provando tutte le chiavi era possibile ottenere il plain text completo. Dunque si capì che DES era sicuro ma la chiave usata dall'algoritmo era troppo piccola!

==In attesa di un nuovo standard l'intuizione fu quella di cifrare più volte il medesimo testo in chiaro:==
![6aeb3e7494dc03a411dbbd496b5c4551.png](:/ba379853b03f4dbda90d1cb5e539cc62)
Si vide che anche il double encryption era soggetto ad un attacco di tipo Meet In The Middle, allora si provò ad inserire un terzo stadio di cifratura ottenendo la cifratura tripla ottenendo un sistema molto più sicuro. In realtà anche nel **3DES** è possibile riprodurre il Meet In The Middle che però richiede un numero pari a 2^118^ cicli. Dunque 3DES viene considerato sicuro e negli utilizzi pratici è usatissimo. Lo svantaggio è che dovendo cifrare 3 volte, <span style="color: #ff3000">3DES è molto lento</span>. Inoltre DES essendo stato progettato negli anni 70 fu progettato per essere eseguito su hardware. Dunque la versione hardware di DES è più efficiente della versione software di 3DES. Ad esempio AES, che è stato poi definito come standard minimo per la sicurezza odierna, è stato progettato per essere sicuro sia in hardware che in software.

***
**Form**
![63c75e37a714a9256d4124fec0275d7b.png](:/1f9ff520387945a69341d567e2d44501)
***

**25/02/2023**
Un cifrario a blocchi abbiamo detto che cifra blocchi di bit in ingresso. Dunque in ingresso ho `n` bit, in uscita ho `n` bit e utilizzo `k` bit di chiave. Dunque un cifrario a blocchi ha 2 ingressi e una sola uscita:
![a4d94d7f9cb3a7caaeefcb34321a1de0.png](:/224499f92888435580191ef33bfd67d5)

Se supponiamo di usare l'algoritmo AES che lavora con n = 128 bit ➡️ 16 byte, avremmo un problema in quanto se il mio cifrario lavorasse solo su 16 byte come mostrato in figura (che corrispondono a 16 caratteri ASCII) potremmo trasmettere poca informazione alla volta usando una sola chiave. 

❓️Cosa succede quando la quantità di dati da firmare è molto più grande della dimensione della chiave?
Per risolvere questo problema si usano le **<span style="color: #ff5300">modalità di cifratura</span>**. Ne esistono tante che servono a risolvere anche problemi diverso da quello presentato. Noi ci limiteremo ai due più conosciuti: **<span style="color: #0083ff">ECB</span>** e ** **.

✅<span style="color: #ffcf00">L'ipotesi che facciamo è che il **plaintext è un multiplo del blocco**</span>. Questa ipotesi la rilasseremo più avanti.

## ECB Electronic Codebook
![f33ef5e4f66aa602e3a296aa44ecbac6.png](:/53c0c6bde77e4dc598bef19d2ba24b4f)
La modalità di cifratura ECB prende il plaintext, lo affetta, ogni fetta ha la dimensione di un blocco, al cui interno ad esempio per AES per ogni blocco ci sono 128 bit (16 byte), ed ogni blocco viene cifrato con chiave `e`. Quello che ottengo è il testo cifrato suddiviso in `n` blocchi.
![6e5d2a6e650aa66f90e2dd2242c6345f.png](:/689d0881894a41f8ace822285a19f16c)
<span style="color: #7fff7f">Pro</span>:
✅ ++**La cifratura può essere parallelizzata**++: se ho ogni blocco può essere cifrata per conto proprio posso avere diverse CPU che parallelizzano il calcolo di cifratura
✅ ++**Non c'è propagazione dell'errore tra i diversi blocchi**++

<span style="color: #ff0000">Contro</span>:
❌ ++**Testi in chiaro uguali producono testi cifrati uguali**++. Infatti i blocchi vengono cifrati separatamente con la chiave `e`, ma se i blocchi sono uguali otterrò sempre lo stesso output. Da un punto di vista della sicurezza è un problema in quanto ECB:
	- **non nasconde i data pattern**: i blocchi uguali di testo in chiaro me li ritrovo cifrati in modo uguale anche nel testo cifrato. Mi sto allontanando dal cifrario perfetto perchè stiamo rilasciando all'attaccante delle informazioni sulla struttura del testo in chiaro.
	Ad esempio se prendiamo questa immagine come sequenza di byte, dove ogni byte mi rappresenta un pixel dell'immagine, prendendo ad esempio i pixel di colore bianco in alto a sinistra indicati, questi vengono cifrati in modo uguale nell'immagine al centro:
![c22836409be730845fc92a36313533cf.png](:/0e13a763d5804bc8825b0d38f2d9c7e7)
I colori sono alterati a causa del processo di cifratura ma la struttura dell'immagine anche nel testo cifrato viene un pò mantenuta, non è esattamente quella di partenza ma una qualche similitudine la ottengo. Ricorda infatti un pò una cifratura monoalfabetica, in quanto ho solo "spostato" il colore (dal bianco al grigio rigato) ma il layout del contenuto viene mantenuto.
 Usando invece CBC (la terza immagina sulla destra) i data pattern vengono nascosti come vedremo dopo.
	- **permette l'analisi del traffico**: 
❌ ++**Permette il riordino o sostituzione dei blocchi**++: supponiamo infatti di aver cifrato il testo in chiaro p~t~ con la modalità ECB ottenendo il testo cifrato c~t~. Lato ricevente, applicherà la decifratura usando la medesima chiave e ottenendo il testo in chiaro di partenza. Dato che ciascuno di questi blocchi è cifrato separatamente, l'attaccante potrebbe prendere due blocchi casualmente e scambiarli di posto:
![c7f005e3fb1bc0bdffe75eb6f899660c.png](:/a56c9656e540440ba3f7798d5e1dea48)
In fase di decifratura è difficile accorgersene di questo scambio se entrambe le informazioni (quella originaria e quella costruita a seguito dello scambio) sono plausibli.
Inoltre se prendo un blocco proveniente da una **cifratura precedente** cifrato con medesima chiave (in <span style="color: #67ff5b">verde rigato</span>) e lo sostituisco al posto di altri blocchi, quando andrò a decifrare, otterrò un valore diverso da quello voluto (**<span style="color: #ffcf00">attacco di malleabilità</span>**):
![ba923d8c9c886c5019a4965c412f44ce.png](:/b989bf7ec6844d518b25045dfd26b9dd)
L'ECB viene usato nella pratica ma presenta questi contro, quindi dobbiamo tenerne conto.

### Block replay attack
Supponiamo di avere un utente `U` che dispone di 2 conti bancari, uno presso la `banca 1` e uno presso la `banca 2`. Vuole trasferire una quantità di soldi da `banca 1` a `banca 2`. Se devo progettare il protocollo, la `banca 1` addebita `D` euro ad `U`, poi invia un messaggio alla `banca 2`, dicendogli di accreditare `D` euro sul conto di `U`, la quale `banca 2` aggiunge questi `D` euro al conto di `U`.

Il formato dei messaggi sarà:
![b47af0ab85f8e77ab969737d7d936676.png](:/3529920964f74b51ba35f75b553a1feb)
 Supponiamo di usare un algoritmo di cifratura come DES con chiave a 64 bit (8 byte).
![b8dc033c346c9589ebc2d11d2b0f7a9b.png](:/29b0030a7f6c4cad8bbf0dbf67dba567)
Supponiamo che l'utente `U` voglia fare una truffa. Ogni volta che la `banca 2` riceve il messaggio replicato (in <span style="color: #ff0000">rosso</span>) con una certa somma di denaro, verrà accreditata quella somma di denaro:
![a2b70f39b992204aea5ecdf26ab8dafe.png](:/dec75a5ed986455e9aed115af0d453f4)

L'attaccante farà un primo trasferimento in cui trasferirà `100` euro dalla `banca 1` alla `banca 2` diretto sempre al suo stesso conto. Non riuscirà a distinguerlo in quanto cifrato e "affogato" tra gli altri messaggi che le banche si inviano per i loro clienti. Allora per distinguere i suoi messaggi invierà un altro messaggio uguale in cui cambierà solamente la somma trasferita (es: 200 euro). Se vuole aumentare le probabilità di riuscire a identificare i suoi messaggi, invierà molti messaggi, tutti uguali tra di loro al netto della cifra trasferita:
![85a38b3be1d097b38239054a9768e549.png](:/566fe82bf0244f3fb88f4174c4026a00)
a quel punto, una volta identificati i suoi messaggi nel calderone dei messaggi della banca, può procedere con l'attacco della replica dei blocchi (<span style="color: #ff0000">freccia in rosso</span>):
![91fd0c0ebc7c84d8f0225e0d632bf23b.png](:/1ed53d9ecdf64c99a48c61b333a4ad61)

![92f8db37a2233506eef28a89e0af3601.png](:/41a2b10e44fb43edac15b77cf848e79b)

In questo protocollo sembra quindi non esserci alcun "ELEMENTO DI FRESCHEZZA", invece usando un <span style="color: #0083ff">**timestamp**</span> ad esempio, il ricevente può capire se si tratta di un messaggio recente o un messaggio vecchio, quindi capire se siamo in caso di <span style="color: #ff5300">Replay attack</span>.

Alteriamo allora il formato dei messaggi aggiungendo un blocco di 8 byte per indicare le marche temporali dei messaggi:
![9276b5859aac21a6fdf544ddfcb4a68d.png](:/a5c46135ab2643358425c5ed50ac0dbd)
a questo punto ++i messaggi non potranno essere più tutti uguali !!!++ ma per lo meno saranno uguali dal blocco 2 al blocco 13 in quanto il blocco 1 corrispondente al timestamp cambia ogni volta. Inoltre è da notare che il blocco 1 corrispondente al timestamp sta su 8 byte dunque il blocco 1 è cifrato separatamente.

Se adesso intercetto il blocco, abbiamo detto che il primo pezzo ha la marca temporale, e quindi come avversario cerco di fare il replay attack, non potrò metterci una marca temporale nuova, in quanto dovrei conoscere la chiave per cifrarne una, quindi la `banca 2` si accorgerà del replay attack scartando il messaggio. Posso però individuare in rete un messaggio di altre transazioni cifrate con la medesima chiave, posso prenderla e sostituirla all'interno della mia transazione e a quel punto l'attaccante può bypassare la soluzione del timestamp. Ovvero ho fatto una sostituzione di blocco.

Dunque questo tipo di cifrario va usato in modo critico, usandolo solo quando la mia specifica applicazione può non soffrire di queste problematiche o comunque quando non sono importanti per il mio caso d'uso.

## CBC Cipher block chaining
![d837c57e81ffb6ad65f6df97108486e1.png](:/fa3a5e73dd324877bd5b58b22bca246d)
La modalità di cifratura è più complessa ed esiste una forma di retroazione in questo caso di cifratura. Prendiamo ad esempio il blocco p~2~, prima di cifrarlo faccio lo XOR con il blocco c~1~ di testo cifrato precedente.

Quando vado a cifrare p~1~ che è il primo blocco, non esistendo un blocco precedente, dovrò usare un <span style="color: #ff78ff">**IV o vettore di inizializzazione**</span>. Con questa modalità di cifratura, in fase di decifratura, lato ricevente, quando arriverà c~2~, lo decifrerò e ne farò lo XOR con c~1~ per ottenere p~2~.

In questo caso supponiamo che ci siano 2 blocchi uguali, ad esempio p~1~ e p~2~. p~1~ viene messo in XOR con l'IV mentre p~2~ viene messo in XOR con c~1~. Questo vuol dire che quello che entra in ingresso al cifrario  sono quantità diverse, ovvero anche se p~1~ e p~2~ sono uguali, dato che viene fatto lo XOR, <span style="color: #ff3000">++gli input saranno diversi anche se i plaintext sono uguali++</span>, proprio grazie all'operazione di "concatenamento". In modo più macroscopico, se cifro due volte lo stesso dato, vorrà dire che i p~1~,p~2~...p~n~ dei 2 dati saranno uguali, ma sarà sufficiente per ogni cifratura (in questo caso 2) cambiare l'IV per avere due testi cifrati diversi anche a parità del plaintext, dunque con l'analisi del traffico un attaccante non riesce più a capire la struttura della comunicazione.

Inoltre abbiamo visto che con ECB si potevano riordinare i blocchi o sostituirli. 
Se ci concentriamo su questa formula:
![e70f24a2dd5d46a5d8a4d397e3d93ad0.png](:/0103eb34b9324f9a907803e68be9c1a5)
essa ci dice in fase di decifratura come calcolare il blocco in chiaro a partire dai blocchi cifrati.
Se supponiamo che il blocco c~i~ venga scambiato oppure sostituito con un blocco precedente dall'attaccante, quello che succede è che vado ad alterare la sequenza, quindi avrò un valore diverso da c~i~ (detto c~i~'), quando vado a decifrare andrò a fare lo XOR con c~i~' che non è il vero blocco precedente, dunque la decifratura non fallisce ma il risultato netto che ottengo sarà una serie di caratteri completamente random e privi di senso (oppure nel caso peggiore potrebbe venir fuori per sfortuna delle vittime un valore sensato per l'applicazione in essere, ma è molto improbabile!).

![bf11e0f2b094c9b4c9b3b9ccf1dd26fc.png](:/2847003a52d4424292e7c8ed46d7967d)
- ⚠️<span style="color: #ff9300">Dunque il riordino o sostituzione di un blocco provoca una rottura in fase di decifratura.</span>⚠️
- La cifratura deve essere fatta in modo sequenziale, mentre la decifratura può essere fatta in modo parallelo in quanto per poter decifrare un qualunque blocco ho bisogno del suo blocco corrispondente e di quello di prima.
- Il vettore di inizializzazione deve essere nuovo per ogni nuovo messaggio, dunque non bisogna mai usare lo stesso IV due volte, si dice che **<span style="color: #ff536a">CBC non è deterministico</span>** perchè a parità di dati, basta cambiare l'IV per ottenere testi cifrati differenti. ++Dunque l'IV randomizza la cifratura++.
L'IV, come tutti gli elementi in generale che servono per conferire freschezza,  viene detto <span style="color: #0055ee">*NONCE*</span> può essere realizzato tramite un contatore oppure può essere generato in modo completamente random. L'IV può essere inviato in chiaro, ma la sua integrità deve essere verificata, in quanto se l'avversario riuscisse a modificarlo, in fase di decifratura si otterrebbe un valore diverso del messaggio voluto.

Esistono altre modalità di cifratura, che non verranno trattate:
![8a5d50071d1a3228ff9e720ab52f5461.png](:/d5e04401f7d5441d951bdfc25eef91e9)

## Padding
L'ipotesi iniziale che avevamo fatto che il testo in chiaro fosse un multiplo del blocco la andiamo a rilassare, infatti:
![8a50dfe2c9bd938a151e85c45862e505.png](:/6abe4dfc7be641b38aa56e033ea152c8)
il problema che vogliamo affrontare è una situazione più generica in cui ci troviamo a fare l'encryption ovvero
il testo in chiaro che vogliamo cifrare viene affettato in blocchi e l'ultimo blocco non è pieno ma gli manca qualche byte. 
Sia che si utilizzi CBC che ECB il cifrario in ingresso vuole sempre un blocco della stessa lunghezza.
Quindi viene effettuata una operazione di **padding** utilizzando dei byte fittizi in modo tale che sul lato della decifratura, vengano scartati i byte aggiuntivi. Però chi riceve non sa quali sono i byte fittizi e quale è la vera lunghezza del messaggio, quindi in qualche modo dobbiamo comunicare questa informazione aggiuntiva. Supponiamo di avere il messaggio `HELLO` completato con dei byte tutti a 0 come valore fittizio.

⚠️<span style="color: #ffcf00">**Il problema di questa soluzione è che se volessi trasmettere il messaggio HELLO0? Potrei avere dei casi in cui lo 0 non è padding ma è parte del mio payload! Inoltre in molti linguaggi di programmazione lo 0 è il carattere di fine stringa, quindi quello 0 dovremmo distinguerlo dal carattere di fine stringa.** </span>

Il trucco che si usa è il seguente: supponiamo di voler scrivere HELLO e mi mancano 3 byte da completare. In questi 3 byte scriverò il numero 3, in quanto sono 3 i byte che devo riempire. Fossero stati solo 2 byte da dover riempire avrei scritto il numero 2 in ciascuno dei 2 byte. Il problema sembrerebbe ripresentarti nel caso in cui io voglia mandare `HELLO3`, il riempimento che mi serve in questo caso è pari a 2 byte, dunque scriverò il carattere 2 come riempimento:
![4ce395c631bb7396c9f59fdf0246eb74.png](:/2f2cbcddeb824fa5b628d5db4be7c6bc)
Con questo metodo riesco quindi sempre a identificare il padding, eccetto in un caso:
supponiamo che l'ultimo blocco contenga l'informazione`HELLO322`, quindi **<span style="color: #ff3000">non ci sarebbe bisogno di padding</span>**, quando però viene ricevuto, gli ultimi 2 byte verrebbero scartati perchè sono posti a 2. Posso allora introdurre un <span style="color: #0083ff">intero blocco fittizio</span> in cui scrivere un blocco da 8 byte con il carattere 8:
![a57a7b4de12614f06b2a53ef2df22d60.png](:/019a940cfcc644d58cc14529de80109b)
a questo punto l'ultimo blocco diventa quello identificato con la freccia e quindi verrà scartato interamente.

Con questo metodo di padding si riesce a tenere conto del fatto che il messaggio non deve avere necessariamente una dimensione che non è un multiplo integrale del blocco.

Dunque il padding espone due attenzioni da prendere in fase di progettazione e utilizzo delle librerie:
1. Se un messaggio in chiaro ha una certa dimensione, il buffer da allocare per contenere il testo cifrato dovrà essere più grande in quanto il padding aumenta la dimensione
2. Se devo trasmettere dei dati, i dati trasmessi sono più grandi di quelli in chiaro, questo normalmente non è un problema se non nel caso di dispositivi embedded o real-time application in cui c'è un dispendio maggiore di energia o storage. Per questo motivo esistono delle modalità di cifratura che mi permettono di evitare il rigonfiamento dovuto al padding.

***
**Form**
**![0efcebf428ca48d7c32d224dec0ba0cb.png](:/d8f542578ee54685aababfce02b5c791)**

❗️domanda 7: non dovrebbe essere necessario il padding in questo caso? quindi dovrebbero essere 16 padded plaintext
***



# Hash Functions

# Digital signatures

# Keys

id: a0afb8cd1a4b4fa2aa51020fdec50c0d
parent_id: f88582bebaa24728a4a9fa616213758a
created_time: 2023-02-04T07:02:38.002Z
updated_time: 2023-02-26T23:16:14.370Z
is_conflict: 0
latitude: 0.00000000
longitude: 0.00000000
altitude: 0.0000
author: 
source_url: 
is_todo: 0
todo_due: 0
todo_completed: 0
source: joplin-desktop
source_application: net.cozic.joplin-desktop
application_data: 
order: 0
user_created_time: 2023-02-04T07:02:38.002Z
user_updated_time: 2023-02-26T23:16:14.370Z
encryption_cipher_text: 
encryption_applied: 0
markup_language: 1
is_shared: 0
share_id: 
conflict_original_id: 
master_key_id: 
type_: 1