b84ee57da159d164dba7498025117d6f.png

id: f5f97eb7bde24dbebcb322de2ca8b93f
mime: image/png
filename: 
created_time: 2023-03-11T12:46:46.072Z
updated_time: 2023-03-11T12:46:46.072Z
user_created_time: 2023-03-11T12:46:46.072Z
user_updated_time: 2023-03-11T12:46:46.072Z
file_extension: png
encryption_cipher_text: 
encryption_applied: 0
encryption_blob_encrypted: 0
size: 119822
is_shared: 0
share_id: 
master_key_id: 
type_: 4