id: c2e9cff0dcaa4df7bf6d7c0dd8d32d78
note_id: fcb8bc8b9c4a49a798bbcbd40c3284f6
tag_id: a62167a090424cb3a5dd221f35d3076c
created_time: 2023-02-04T08:59:26.890Z
updated_time: 2023-02-04T08:59:26.890Z
user_created_time: 2023-02-04T08:59:26.890Z
user_updated_time: 2023-02-04T08:59:26.890Z
encryption_cipher_text: 
encryption_applied: 0
is_shared: 0
type_: 6