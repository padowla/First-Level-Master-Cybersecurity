4ce395c631bb7396c9f59fdf0246eb74.png

id: 2f2cbcddeb824fa5b628d5db4be7c6bc
mime: image/png
filename: 
created_time: 2023-02-25T10:53:38.624Z
updated_time: 2023-02-25T10:53:38.624Z
user_created_time: 2023-02-25T10:53:38.624Z
user_updated_time: 2023-02-25T10:53:38.624Z
file_extension: png
encryption_cipher_text: 
encryption_applied: 0
encryption_blob_encrypted: 0
size: 22473
is_shared: 0
share_id: 
master_key_id: 
type_: 4