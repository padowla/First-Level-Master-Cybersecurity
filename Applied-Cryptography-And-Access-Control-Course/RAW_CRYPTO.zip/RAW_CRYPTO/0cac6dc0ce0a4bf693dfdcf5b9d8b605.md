6ed809f16bd49f4fe2d5fb5fdaaa4d9f.png

id: 0cac6dc0ce0a4bf693dfdcf5b9d8b605
mime: image/png
filename: 
created_time: 2023-04-04T07:29:05.027Z
updated_time: 2023-04-04T07:29:05.027Z
user_created_time: 2023-04-04T07:29:05.027Z
user_updated_time: 2023-04-04T07:29:05.027Z
file_extension: png
encryption_cipher_text: 
encryption_applied: 0
encryption_blob_encrypted: 0
size: 95589
is_shared: 0
share_id: 
master_key_id: 
type_: 4