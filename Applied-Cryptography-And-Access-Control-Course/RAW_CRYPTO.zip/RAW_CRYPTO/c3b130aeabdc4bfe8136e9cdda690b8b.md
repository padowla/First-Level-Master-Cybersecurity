2d5607bb1d1e51140a1c1c08fa010daf.png

id: c3b130aeabdc4bfe8136e9cdda690b8b
mime: image/png
filename: 
created_time: 2023-03-11T12:24:31.712Z
updated_time: 2023-03-11T12:24:31.712Z
user_created_time: 2023-03-11T12:24:31.712Z
user_updated_time: 2023-03-11T12:24:31.712Z
file_extension: png
encryption_cipher_text: 
encryption_applied: 0
encryption_blob_encrypted: 0
size: 114631
is_shared: 0
share_id: 
master_key_id: 
type_: 4