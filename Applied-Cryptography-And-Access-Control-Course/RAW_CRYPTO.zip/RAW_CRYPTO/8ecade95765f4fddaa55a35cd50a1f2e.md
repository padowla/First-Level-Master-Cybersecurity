63fe57b43ca56ed49ada34e6b82a736c.png

id: 8ecade95765f4fddaa55a35cd50a1f2e
mime: image/png
filename: 
created_time: 2023-04-14T13:21:50.036Z
updated_time: 2023-04-14T13:21:50.036Z
user_created_time: 2023-04-14T13:21:50.036Z
user_updated_time: 2023-04-14T13:21:50.036Z
file_extension: png
encryption_cipher_text: 
encryption_applied: 0
encryption_blob_encrypted: 0
size: 234334
is_shared: 0
share_id: 
master_key_id: 
type_: 4