0654df50f8727632da6fd715205c6431.png

id: 2d175dc5fbd64fa78e1faedaa95fb13f
mime: image/png
filename: 
created_time: 2023-04-14T12:05:08.885Z
updated_time: 2023-04-14T12:05:08.885Z
user_created_time: 2023-04-14T12:05:08.885Z
user_updated_time: 2023-04-14T12:05:08.885Z
file_extension: png
encryption_cipher_text: 
encryption_applied: 0
encryption_blob_encrypted: 0
size: 188334
is_shared: 0
share_id: 
master_key_id: 
type_: 4