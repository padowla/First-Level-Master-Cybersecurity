953b5a9064891fc472e1ce0b1bd59aa2.png

id: 4cc72e4dde3743cfa60ccf0cd7ce945c
mime: image/png
filename: 
created_time: 2023-02-18T08:15:05.354Z
updated_time: 2023-02-18T08:15:05.354Z
user_created_time: 2023-02-18T08:15:05.354Z
user_updated_time: 2023-02-18T08:15:05.354Z
file_extension: png
encryption_cipher_text: 
encryption_applied: 0
encryption_blob_encrypted: 0
size: 214117
is_shared: 0
share_id: 
master_key_id: 
type_: 4