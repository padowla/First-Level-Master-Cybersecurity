95785089323f798e1ed7e64c2e2e844e.png

id: 0f48dffd841a4fe7b7e886adcc8b99af
mime: image/png
filename: 
created_time: 2023-03-07T20:01:07.919Z
updated_time: 2023-03-07T20:01:07.919Z
user_created_time: 2023-03-07T20:01:07.919Z
user_updated_time: 2023-03-07T20:01:07.919Z
file_extension: png
encryption_cipher_text: 
encryption_applied: 0
encryption_blob_encrypted: 0
size: 426777
is_shared: 0
share_id: 
master_key_id: 
type_: 4