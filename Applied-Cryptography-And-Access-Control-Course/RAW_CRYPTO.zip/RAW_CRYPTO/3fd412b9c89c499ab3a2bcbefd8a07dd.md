bdb14d0b0cb13ca10ee48058e5d6ba8b.png

id: 3fd412b9c89c499ab3a2bcbefd8a07dd
mime: image/png
filename: 
created_time: 2023-03-25T07:35:14.269Z
updated_time: 2023-03-25T07:35:14.269Z
user_created_time: 2023-03-25T07:35:14.269Z
user_updated_time: 2023-03-25T07:35:14.269Z
file_extension: png
encryption_cipher_text: 
encryption_applied: 0
encryption_blob_encrypted: 0
size: 206287
is_shared: 0
share_id: 
master_key_id: 
type_: 4