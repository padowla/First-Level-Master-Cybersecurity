ca4b0e97a84bea61d8959d50adc1bf68.png

id: e1198ffbfc854be9a624d1b0abed9d7c
mime: image/png
filename: 
created_time: 2023-04-14T12:14:07.709Z
updated_time: 2023-04-14T12:14:07.709Z
user_created_time: 2023-04-14T12:14:07.709Z
user_updated_time: 2023-04-14T12:14:07.709Z
file_extension: png
encryption_cipher_text: 
encryption_applied: 0
encryption_blob_encrypted: 0
size: 15816
is_shared: 0
share_id: 
master_key_id: 
type_: 4