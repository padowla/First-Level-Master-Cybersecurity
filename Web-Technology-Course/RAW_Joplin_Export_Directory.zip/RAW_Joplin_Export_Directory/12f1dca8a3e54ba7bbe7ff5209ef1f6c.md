e99cbac853b472fae82b77476fe061ed.png

id: 12f1dca8a3e54ba7bbe7ff5209ef1f6c
mime: image/png
filename: 
created_time: 2023-02-03T15:44:54.907Z
updated_time: 2023-02-03T15:44:54.907Z
user_created_time: 2023-02-03T15:44:54.907Z
user_updated_time: 2023-02-03T15:44:54.907Z
file_extension: png
encryption_cipher_text: 
encryption_applied: 0
encryption_blob_encrypted: 0
size: 474415
is_shared: 0
share_id: 
master_key_id: 
type_: 4