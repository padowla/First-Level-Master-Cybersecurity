dac0086bf0eb29dec3ffb57e6f566130.png

id: d5c13e4ef47347d1be7cf68ecf18fcde
mime: image/png
filename: 
created_time: 2023-05-20T10:59:07.666Z
updated_time: 2023-05-20T10:59:07.666Z
user_created_time: 2023-05-20T10:59:07.666Z
user_updated_time: 2023-05-20T10:59:07.666Z
file_extension: png
encryption_cipher_text: 
encryption_applied: 0
encryption_blob_encrypted: 0
size: 104672
is_shared: 0
share_id: 
master_key_id: 
type_: 4