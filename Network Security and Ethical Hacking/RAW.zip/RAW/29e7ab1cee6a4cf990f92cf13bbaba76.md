9c1a6cd9a97ae03a7f1fd2c5ead8186c.png

id: 29e7ab1cee6a4cf990f92cf13bbaba76
mime: image/png
filename: 
created_time: 2023-07-07T16:05:28.022Z
updated_time: 2023-07-07T16:05:28.022Z
user_created_time: 2023-07-07T16:05:28.022Z
user_updated_time: 2023-07-07T16:05:28.022Z
file_extension: png
encryption_cipher_text: 
encryption_applied: 0
encryption_blob_encrypted: 0
size: 253543
is_shared: 0
share_id: 
master_key_id: 
type_: 4