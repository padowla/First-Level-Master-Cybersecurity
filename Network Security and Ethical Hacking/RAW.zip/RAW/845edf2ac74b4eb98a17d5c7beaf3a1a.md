4dd4770613b131619c56df605231f555.png

id: 845edf2ac74b4eb98a17d5c7beaf3a1a
mime: image/png
filename: 
created_time: 2023-05-26T16:42:46.556Z
updated_time: 2023-05-26T16:42:46.556Z
user_created_time: 2023-05-26T16:42:46.556Z
user_updated_time: 2023-05-26T16:42:46.556Z
file_extension: png
encryption_cipher_text: 
encryption_applied: 0
encryption_blob_encrypted: 0
size: 240927
is_shared: 0
share_id: 
master_key_id: 
type_: 4