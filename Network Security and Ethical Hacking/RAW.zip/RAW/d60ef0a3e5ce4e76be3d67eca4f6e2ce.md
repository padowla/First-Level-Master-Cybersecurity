06eebc4e4eec6481a1fbd691933ec115.png

id: d60ef0a3e5ce4e76be3d67eca4f6e2ce
mime: image/png
filename: 
created_time: 2023-07-17T22:19:23.696Z
updated_time: 2023-07-17T22:19:23.696Z
user_created_time: 2023-07-17T22:19:23.696Z
user_updated_time: 2023-07-17T22:19:23.696Z
file_extension: png
encryption_cipher_text: 
encryption_applied: 0
encryption_blob_encrypted: 0
size: 123172
is_shared: 0
share_id: 
master_key_id: 
type_: 4