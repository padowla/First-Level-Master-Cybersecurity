fd0c4f1add161defe88ec25e30dde3ad.png

id: b7c42acea6e441bebcb9a38ba3444fbc
mime: image/png
filename: 
created_time: 2023-05-26T17:14:59.328Z
updated_time: 2023-05-26T17:14:59.328Z
user_created_time: 2023-05-26T17:14:59.328Z
user_updated_time: 2023-05-26T17:14:59.328Z
file_extension: png
encryption_cipher_text: 
encryption_applied: 0
encryption_blob_encrypted: 0
size: 376540
is_shared: 0
share_id: 
master_key_id: 
type_: 4