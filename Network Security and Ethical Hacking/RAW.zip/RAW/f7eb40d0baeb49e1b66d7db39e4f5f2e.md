e1b7c5e12427c37dbc72006810bbf9d3.png

id: f7eb40d0baeb49e1b66d7db39e4f5f2e
mime: image/png
filename: 
created_time: 2023-07-14T22:34:03.680Z
updated_time: 2023-07-14T22:34:03.680Z
user_created_time: 2023-07-14T22:34:03.680Z
user_updated_time: 2023-07-14T22:34:03.680Z
file_extension: png
encryption_cipher_text: 
encryption_applied: 0
encryption_blob_encrypted: 0
size: 426080
is_shared: 0
share_id: 
master_key_id: 
type_: 4