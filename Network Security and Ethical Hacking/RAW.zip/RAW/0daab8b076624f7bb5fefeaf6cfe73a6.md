86976ff6bf865ba2a950f32410b41b75.png

id: 0daab8b076624f7bb5fefeaf6cfe73a6
mime: image/png
filename: 
created_time: 2023-07-16T21:46:46.455Z
updated_time: 2023-07-16T21:46:46.455Z
user_created_time: 2023-07-16T21:46:46.455Z
user_updated_time: 2023-07-16T21:46:46.455Z
file_extension: png
encryption_cipher_text: 
encryption_applied: 0
encryption_blob_encrypted: 0
size: 322811
is_shared: 0
share_id: 
master_key_id: 
type_: 4