f6db52cac032eb1d8d40d97f8b452ad2.png

id: f9d52fd6afe24835baba49db51cadd8a
mime: image/png
filename: 
created_time: 2023-07-16T21:34:32.887Z
updated_time: 2023-07-16T21:34:32.887Z
user_created_time: 2023-07-16T21:34:32.887Z
user_updated_time: 2023-07-16T21:34:32.887Z
file_extension: png
encryption_cipher_text: 
encryption_applied: 0
encryption_blob_encrypted: 0
size: 106052
is_shared: 0
share_id: 
master_key_id: 
type_: 4