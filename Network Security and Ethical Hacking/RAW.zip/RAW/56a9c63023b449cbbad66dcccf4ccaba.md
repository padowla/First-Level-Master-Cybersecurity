512949b2dea847aa8bf07368d782e642.png

id: 56a9c63023b449cbbad66dcccf4ccaba
mime: image/png
filename: 
created_time: 2023-05-26T16:47:43.509Z
updated_time: 2023-05-26T16:47:43.509Z
user_created_time: 2023-05-26T16:47:43.509Z
user_updated_time: 2023-05-26T16:47:43.509Z
file_extension: png
encryption_cipher_text: 
encryption_applied: 0
encryption_blob_encrypted: 0
size: 233400
is_shared: 0
share_id: 
master_key_id: 
type_: 4