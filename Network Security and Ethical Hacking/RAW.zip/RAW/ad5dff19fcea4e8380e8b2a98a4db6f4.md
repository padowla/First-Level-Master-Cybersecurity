19b26de6b6acb2ab644dd27b766c7e27.png

id: ad5dff19fcea4e8380e8b2a98a4db6f4
mime: image/png
filename: 
created_time: 2023-05-20T11:34:00.756Z
updated_time: 2023-05-20T11:34:00.756Z
user_created_time: 2023-05-20T11:34:00.756Z
user_updated_time: 2023-05-20T11:34:00.756Z
file_extension: png
encryption_cipher_text: 
encryption_applied: 0
encryption_blob_encrypted: 0
size: 202930
is_shared: 0
share_id: 
master_key_id: 
type_: 4