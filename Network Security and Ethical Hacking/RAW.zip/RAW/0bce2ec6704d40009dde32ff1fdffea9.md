02cf11bfd074917f281bc9b249102843.png

id: 0bce2ec6704d40009dde32ff1fdffea9
mime: image/png
filename: 
created_time: 2023-06-09T16:58:57.638Z
updated_time: 2023-06-09T16:58:57.638Z
user_created_time: 2023-06-09T16:58:57.638Z
user_updated_time: 2023-06-09T16:58:57.638Z
file_extension: png
encryption_cipher_text: 
encryption_applied: 0
encryption_blob_encrypted: 0
size: 213094
is_shared: 0
share_id: 
master_key_id: 
type_: 4