9893c7464d1eb2038125360473c4c465.png

id: 9d6cf7d0ba9e4caa843cdc5f90f3d53e
mime: image/png
filename: 
created_time: 2023-07-16T15:42:55.434Z
updated_time: 2023-07-16T15:42:55.434Z
user_created_time: 2023-07-16T15:42:55.434Z
user_updated_time: 2023-07-16T15:42:55.434Z
file_extension: png
encryption_cipher_text: 
encryption_applied: 0
encryption_blob_encrypted: 0
size: 329857
is_shared: 0
share_id: 
master_key_id: 
type_: 4