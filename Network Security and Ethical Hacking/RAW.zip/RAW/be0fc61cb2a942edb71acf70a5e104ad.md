7c256e2013e29cc3c6b2b4384c877f81.png

id: be0fc61cb2a942edb71acf70a5e104ad
mime: image/png
filename: 
created_time: 2023-05-26T16:23:47.440Z
updated_time: 2023-05-26T16:23:47.440Z
user_created_time: 2023-05-26T16:23:47.440Z
user_updated_time: 2023-05-26T16:23:47.440Z
file_extension: png
encryption_cipher_text: 
encryption_applied: 0
encryption_blob_encrypted: 0
size: 341536
is_shared: 0
share_id: 
master_key_id: 
type_: 4