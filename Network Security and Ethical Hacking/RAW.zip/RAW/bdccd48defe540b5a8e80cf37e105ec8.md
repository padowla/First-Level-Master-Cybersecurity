741d9dd1c684b34a7c195a3eaf38692b.png

id: bdccd48defe540b5a8e80cf37e105ec8
mime: image/png
filename: 
created_time: 2023-07-19T20:23:54.908Z
updated_time: 2023-07-19T20:23:54.908Z
user_created_time: 2023-07-19T20:23:54.908Z
user_updated_time: 2023-07-19T20:23:54.908Z
file_extension: png
encryption_cipher_text: 
encryption_applied: 0
encryption_blob_encrypted: 0
size: 263187
is_shared: 0
share_id: 
master_key_id: 
type_: 4