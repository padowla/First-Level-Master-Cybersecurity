b48ef30400f61290d77eb9685ceb2818.png

id: cf782eaad8bf48b5aeefc677328d6ee0
mime: image/png
filename: 
created_time: 2023-05-26T17:26:04.079Z
updated_time: 2023-05-26T17:26:04.079Z
user_created_time: 2023-05-26T17:26:04.079Z
user_updated_time: 2023-05-26T17:26:04.079Z
file_extension: png
encryption_cipher_text: 
encryption_applied: 0
encryption_blob_encrypted: 0
size: 166008
is_shared: 0
share_id: 
master_key_id: 
type_: 4