7af541566750f82164286864e2f05ae4.png

id: 2be3e625d67f4db9aede23e39ede49bc
mime: image/png
filename: 
created_time: 2023-07-16T15:30:53.596Z
updated_time: 2023-07-16T15:30:53.596Z
user_created_time: 2023-07-16T15:30:53.596Z
user_updated_time: 2023-07-16T15:30:53.596Z
file_extension: png
encryption_cipher_text: 
encryption_applied: 0
encryption_blob_encrypted: 0
size: 215958
is_shared: 0
share_id: 
master_key_id: 
type_: 4