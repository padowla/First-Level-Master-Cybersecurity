8964b5a7da2ef8b3d4de95839fcf8135.png

id: ebbb06c1b3f14ac0a94ac3e8b4028bfa
mime: image/png
filename: 
created_time: 2023-05-13T11:00:52.990Z
updated_time: 2023-05-13T11:00:52.990Z
user_created_time: 2023-05-13T11:00:52.990Z
user_updated_time: 2023-05-13T11:00:52.990Z
file_extension: png
encryption_cipher_text: 
encryption_applied: 0
encryption_blob_encrypted: 0
size: 147740
is_shared: 0
share_id: 
master_key_id: 
type_: 4