b0138009227dc87e6bb4a3331be00ba2.png

id: 49acac2b62ce425dbebada24f895a6df
mime: image/png
filename: 
created_time: 2023-06-17T06:21:57.705Z
updated_time: 2023-06-17T06:21:57.705Z
user_created_time: 2023-06-17T06:21:57.705Z
user_updated_time: 2023-06-17T06:21:57.705Z
file_extension: png
encryption_cipher_text: 
encryption_applied: 0
encryption_blob_encrypted: 0
size: 347786
is_shared: 0
share_id: 
master_key_id: 
type_: 4