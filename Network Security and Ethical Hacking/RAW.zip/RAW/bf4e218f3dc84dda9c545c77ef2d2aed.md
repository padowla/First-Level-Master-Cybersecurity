449c794e2eb29adc714e94323f7473c0.png

id: bf4e218f3dc84dda9c545c77ef2d2aed
mime: image/png
filename: 
created_time: 2023-05-26T16:41:37.683Z
updated_time: 2023-05-26T16:41:37.683Z
user_created_time: 2023-05-26T16:41:37.683Z
user_updated_time: 2023-05-26T16:41:37.683Z
file_extension: png
encryption_cipher_text: 
encryption_applied: 0
encryption_blob_encrypted: 0
size: 243555
is_shared: 0
share_id: 
master_key_id: 
type_: 4