cb5f44aeee22e738254109f30331a3ec.png

id: 47e0c0fcfb1a4e3fb5cea716c347dbad
mime: image/png
filename: 
created_time: 2023-02-04T09:39:38.601Z
updated_time: 2023-02-04T09:39:38.601Z
user_created_time: 2023-02-04T09:39:38.601Z
user_updated_time: 2023-02-04T09:39:38.601Z
file_extension: png
encryption_cipher_text: 
encryption_applied: 0
encryption_blob_encrypted: 0
size: 233061
is_shared: 0
share_id: 
master_key_id: 
type_: 4