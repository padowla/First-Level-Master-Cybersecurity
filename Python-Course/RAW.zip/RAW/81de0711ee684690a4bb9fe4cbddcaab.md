5c760280f364d9534166606e50053062.png

id: 81de0711ee684690a4bb9fe4cbddcaab
mime: image/png
filename: 
created_time: 2023-02-17T13:43:19.603Z
updated_time: 2023-02-17T13:43:19.603Z
user_created_time: 2023-02-17T13:43:19.603Z
user_updated_time: 2023-02-17T13:43:19.603Z
file_extension: png
encryption_cipher_text: 
encryption_applied: 0
encryption_blob_encrypted: 0
size: 55648
is_shared: 0
share_id: 
master_key_id: 
type_: 4