d5233e6f139a742a15c9f51e75f1399b.png

id: ce4c8edc312c47da8b1ffe6907acfb29
mime: image/png
filename: 
created_time: 2023-02-17T13:55:54.235Z
updated_time: 2023-02-17T13:55:54.235Z
user_created_time: 2023-02-17T13:55:54.235Z
user_updated_time: 2023-02-17T13:55:54.235Z
file_extension: png
encryption_cipher_text: 
encryption_applied: 0
encryption_blob_encrypted: 0
size: 199722
is_shared: 0
share_id: 
master_key_id: 
type_: 4