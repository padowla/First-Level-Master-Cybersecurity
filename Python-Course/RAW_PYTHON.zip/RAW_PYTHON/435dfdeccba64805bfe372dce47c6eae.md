id: 435dfdeccba64805bfe372dce47c6eae
note_id: 3a89ef14ff504012b2136d1dea1a3984
tag_id: 173eedcb9b874dd68247c35ac942206d
created_time: 2023-02-03T13:10:21.568Z
updated_time: 2023-02-17T13:07:27.328Z
user_created_time: 2023-02-03T13:10:21.568Z
user_updated_time: 2023-02-17T13:07:27.328Z
encryption_cipher_text: 
encryption_applied: 0
is_shared: 0
type_: 6