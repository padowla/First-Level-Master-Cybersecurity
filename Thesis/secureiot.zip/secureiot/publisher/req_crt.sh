#!/bin/sh

# Define the URL and port of the service you're waiting for
SERVICE_URL="http://ejbca-node1:8080/ejbca/publicweb/healthcheck/ejbcahealth" 

until $(curl --output /dev/null --silent --head --fail $SERVICE_URL); do
    echo "Waiting for the service to be available..."
    sleep 5
done

echo "EJBCA available, publisher requesting certificate..."

# Create a CSR
openssl req -new -out publisher.csr -newkey rsa:2048 -nodes -sha256 -keyout publisher.key -subj "/CN=publisher"

# Make the script runnable
chmod a+x pkcs10Enroll.sh

# Request the certificate
./pkcs10Enroll.sh -c publisher.csr -P SuperAdmin.p12 -s foo123 -H ejbca-node1:8443 -t IoTCA.crt -u superadmin -p "SERVER" -e "EMPTY" -n "IoTCA"

# Rename the certificate
mv superadmin.crt publisher.crt

# Check the exit status of openssl
if [ $? -eq 0 ]; then
  echo "Certificate requested done correctly!" 
  cp publisher.crt /
  cp IoTCA.crt /
  cp publisher.key /
else
  echo "Error during certificate request! Check logs"
fi

tail -f /dev/null

