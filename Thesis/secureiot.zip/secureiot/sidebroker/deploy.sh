#!/bin/sh

# Define the URL and port of the service you're waiting for
SERVICE_URL="http://ejbca-node1:8080/ejbca/publicweb/healthcheck/ejbcahealth" 

until $(curl --output /dev/null --silent --head --fail $SERVICE_URL); do
    echo "Waiting for the service to be available..."
    sleep 5
done

echo "EJBCA available, requesting certificate..."

# Create a CSR
openssl req -new -out broker.csr -newkey rsa:2048 -nodes -sha256 -keyout broker.key -subj "/CN=broker"

# Make the script runnable
chmod a+x pkcs10Enroll.sh

# Request the certificate
./pkcs10Enroll.sh -c broker.csr -P SuperAdmin.p12 -s foo123 -H ejbca-node1:8443 -t IoTCA.pem -u superadmin -p "SERVER" -e "EMPTY" -n "IoTCA"

# Rename the certificate
mv superadmin.crt broker.crt

# Check the exit status of openssl
if [ $? -eq 0 ]; then
  echo "Certificate requested done correctly!"
else
  echo "Error during certificate request! Check logs"
  exit 1
fi

mv broker.crt /mosquitto/certs
mv broker.key /mosquitto/keys

exit 0
