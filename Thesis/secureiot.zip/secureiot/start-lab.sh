#!/bin/bash
docker compose down
docker compose rm -f
docker rmi -f $(docker images -q)
docker compose up -d
