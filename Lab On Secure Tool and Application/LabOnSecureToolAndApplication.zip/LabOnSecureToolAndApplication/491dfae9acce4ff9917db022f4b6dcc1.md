415aa058a090a8080057c12b1ba63940.png

id: 491dfae9acce4ff9917db022f4b6dcc1
mime: image/png
filename: 
created_time: 2023-10-06T21:38:19.885Z
updated_time: 2023-10-06T21:38:19.885Z
user_created_time: 2023-10-06T21:38:19.885Z
user_updated_time: 2023-10-06T21:38:19.885Z
file_extension: png
encryption_cipher_text: 
encryption_applied: 0
encryption_blob_encrypted: 0
size: 182657
is_shared: 0
share_id: 
master_key_id: 
user_data: 
blob_updated_time: 1696628299885
type_: 4