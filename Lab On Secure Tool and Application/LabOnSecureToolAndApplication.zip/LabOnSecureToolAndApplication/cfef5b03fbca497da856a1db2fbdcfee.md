6dddc48a1ce1ccd6d7b2cbb1f449fd98.png

id: cfef5b03fbca497da856a1db2fbdcfee
mime: image/png
filename: 
created_time: 2023-10-25T20:35:04.965Z
updated_time: 2023-10-25T20:35:04.965Z
user_created_time: 2023-10-25T20:35:04.965Z
user_updated_time: 2023-10-25T20:35:04.965Z
file_extension: png
encryption_cipher_text: 
encryption_applied: 0
encryption_blob_encrypted: 0
size: 140880
is_shared: 0
share_id: 
master_key_id: 
user_data: 
blob_updated_time: 1698266104965
type_: 4