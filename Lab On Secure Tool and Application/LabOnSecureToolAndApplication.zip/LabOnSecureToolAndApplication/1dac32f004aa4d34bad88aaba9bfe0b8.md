d663c238a44fdf2966f2a3cdb2c47749.png

id: 1dac32f004aa4d34bad88aaba9bfe0b8
mime: image/png
filename: 
created_time: 2023-10-06T21:20:19.766Z
updated_time: 2023-10-06T21:20:19.766Z
user_created_time: 2023-10-06T21:20:19.766Z
user_updated_time: 2023-10-06T21:20:19.766Z
file_extension: png
encryption_cipher_text: 
encryption_applied: 0
encryption_blob_encrypted: 0
size: 114689
is_shared: 0
share_id: 
master_key_id: 
user_data: 
blob_updated_time: 1696627219766
type_: 4