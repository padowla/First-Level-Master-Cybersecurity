320b88a67a9eaac2520c5c137e2dc354.png

id: 2b12a68a5dae46fabbfed4ea642bb121
mime: image/png
filename: 
created_time: 2023-10-23T20:21:05.007Z
updated_time: 2023-10-23T20:21:05.007Z
user_created_time: 2023-10-23T20:21:05.007Z
user_updated_time: 2023-10-23T20:21:05.007Z
file_extension: png
encryption_cipher_text: 
encryption_applied: 0
encryption_blob_encrypted: 0
size: 138836
is_shared: 0
share_id: 
master_key_id: 
user_data: 
blob_updated_time: 1698092465007
type_: 4