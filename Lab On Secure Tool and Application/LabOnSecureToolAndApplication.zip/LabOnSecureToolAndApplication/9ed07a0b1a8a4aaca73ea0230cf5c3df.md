528d28e4bb491860308faf28986e8965.png

id: 9ed07a0b1a8a4aaca73ea0230cf5c3df
mime: image/png
filename: 
created_time: 2023-10-06T21:30:32.753Z
updated_time: 2023-10-06T21:30:32.753Z
user_created_time: 2023-10-06T21:30:32.753Z
user_updated_time: 2023-10-06T21:30:32.753Z
file_extension: png
encryption_cipher_text: 
encryption_applied: 0
encryption_blob_encrypted: 0
size: 271832
is_shared: 0
share_id: 
master_key_id: 
user_data: 
blob_updated_time: 1696627832753
type_: 4