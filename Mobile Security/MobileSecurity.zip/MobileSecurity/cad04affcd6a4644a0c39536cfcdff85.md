96eaeeafc76fa5b0b9fbeb8e158dc845.png

id: cad04affcd6a4644a0c39536cfcdff85
mime: image/png
filename: 
created_time: 2023-10-13T14:32:47.175Z
updated_time: 2023-10-13T14:32:47.175Z
user_created_time: 2023-10-13T14:32:47.175Z
user_updated_time: 2023-10-13T14:32:47.175Z
file_extension: png
encryption_cipher_text: 
encryption_applied: 0
encryption_blob_encrypted: 0
size: 174023
is_shared: 0
share_id: 
master_key_id: 
user_data: 
blob_updated_time: 1697207567175
type_: 4