1a8c87113bdd63b2e7ea6975801ab043.png

id: edf4c7909b2b45feaced97121bd80abc
mime: image/png
filename: 
created_time: 2023-10-16T21:00:32.947Z
updated_time: 2023-10-16T21:00:32.947Z
user_created_time: 2023-10-16T21:00:32.947Z
user_updated_time: 2023-10-16T21:00:32.947Z
file_extension: png
encryption_cipher_text: 
encryption_applied: 0
encryption_blob_encrypted: 0
size: 261325
is_shared: 0
share_id: 
master_key_id: 
user_data: 
blob_updated_time: 1697490032947
type_: 4