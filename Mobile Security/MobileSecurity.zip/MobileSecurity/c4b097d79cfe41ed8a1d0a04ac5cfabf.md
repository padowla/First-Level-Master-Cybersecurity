ab925b3169b2ac4f5b0be8a5ce1c6d56.png

id: c4b097d79cfe41ed8a1d0a04ac5cfabf
mime: image/png
filename: 
created_time: 2023-10-16T20:57:02.737Z
updated_time: 2023-10-16T20:57:02.737Z
user_created_time: 2023-10-16T20:57:02.737Z
user_updated_time: 2023-10-16T20:57:02.737Z
file_extension: png
encryption_cipher_text: 
encryption_applied: 0
encryption_blob_encrypted: 0
size: 331695
is_shared: 0
share_id: 
master_key_id: 
user_data: 
blob_updated_time: 1697489822737
type_: 4