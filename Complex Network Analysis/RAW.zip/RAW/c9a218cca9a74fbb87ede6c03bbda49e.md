e4f9bc5f28fcc73c426d58b245aae293.png

id: c9a218cca9a74fbb87ede6c03bbda49e
mime: image/png
filename: 
created_time: 2023-05-13T06:13:52.250Z
updated_time: 2023-05-13T06:13:52.250Z
user_created_time: 2023-05-13T06:13:52.250Z
user_updated_time: 2023-05-13T06:13:52.250Z
file_extension: png
encryption_cipher_text: 
encryption_applied: 0
encryption_blob_encrypted: 0
size: 566306
is_shared: 0
share_id: 
master_key_id: 
type_: 4