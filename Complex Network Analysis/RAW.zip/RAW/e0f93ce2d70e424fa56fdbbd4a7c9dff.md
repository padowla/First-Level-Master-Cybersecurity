f3c8b7d63abec6985be56d00f9052ebb.png

id: e0f93ce2d70e424fa56fdbbd4a7c9dff
mime: image/png
filename: 
created_time: 2023-05-27T10:20:18.822Z
updated_time: 2023-05-27T10:20:18.822Z
user_created_time: 2023-05-27T10:20:18.822Z
user_updated_time: 2023-05-27T10:20:18.822Z
file_extension: png
encryption_cipher_text: 
encryption_applied: 0
encryption_blob_encrypted: 0
size: 98201
is_shared: 0
share_id: 
master_key_id: 
type_: 4