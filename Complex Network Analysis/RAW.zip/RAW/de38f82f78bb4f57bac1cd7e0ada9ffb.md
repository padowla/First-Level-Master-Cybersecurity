3e4b093d951ef7f48ffa34205dcc528e.png

id: de38f82f78bb4f57bac1cd7e0ada9ffb
mime: image/png
filename: 
created_time: 2023-07-01T07:09:26.830Z
updated_time: 2023-07-01T07:09:26.830Z
user_created_time: 2023-07-01T07:09:26.830Z
user_updated_time: 2023-07-01T07:09:26.830Z
file_extension: png
encryption_cipher_text: 
encryption_applied: 0
encryption_blob_encrypted: 0
size: 113542
is_shared: 0
share_id: 
master_key_id: 
type_: 4