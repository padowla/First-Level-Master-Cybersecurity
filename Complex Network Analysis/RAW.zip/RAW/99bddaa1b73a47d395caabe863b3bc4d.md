549fcdbe3bc7b972d7adcc40349acb8f.png

id: 99bddaa1b73a47d395caabe863b3bc4d
mime: image/png
filename: 
created_time: 2023-05-13T07:04:38.194Z
updated_time: 2023-05-13T07:04:38.194Z
user_created_time: 2023-05-13T07:04:38.194Z
user_updated_time: 2023-05-13T07:04:38.194Z
file_extension: png
encryption_cipher_text: 
encryption_applied: 0
encryption_blob_encrypted: 0
size: 381442
is_shared: 0
share_id: 
master_key_id: 
type_: 4