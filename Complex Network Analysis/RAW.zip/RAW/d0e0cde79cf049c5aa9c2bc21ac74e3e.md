ecf8d494c34c7d164321193c59c6569c.png

id: d0e0cde79cf049c5aa9c2bc21ac74e3e
mime: image/png
filename: 
created_time: 2023-06-07T21:13:35.903Z
updated_time: 2023-06-07T21:13:35.903Z
user_created_time: 2023-06-07T21:13:35.903Z
user_updated_time: 2023-06-07T21:13:35.903Z
file_extension: png
encryption_cipher_text: 
encryption_applied: 0
encryption_blob_encrypted: 0
size: 168604
is_shared: 0
share_id: 
master_key_id: 
type_: 4