2fdcb15de2842b3061c23a51f02c20b1.png

id: 3956bef2fbe4499e8c8fdda3dfc7d3d9
mime: image/png
filename: 
created_time: 2023-07-01T07:01:21.931Z
updated_time: 2023-07-01T07:01:21.931Z
user_created_time: 2023-07-01T07:01:21.931Z
user_updated_time: 2023-07-01T07:01:21.931Z
file_extension: png
encryption_cipher_text: 
encryption_applied: 0
encryption_blob_encrypted: 0
size: 165824
is_shared: 0
share_id: 
master_key_id: 
type_: 4