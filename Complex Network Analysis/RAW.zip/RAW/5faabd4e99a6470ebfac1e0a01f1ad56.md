3dcc8872f7a8ae3a571b8e79d61e2205.png

id: 5faabd4e99a6470ebfac1e0a01f1ad56
mime: image/png
filename: 
created_time: 2023-06-30T12:34:28.945Z
updated_time: 2023-06-30T12:34:28.945Z
user_created_time: 2023-06-30T12:34:28.945Z
user_updated_time: 2023-06-30T12:34:28.945Z
file_extension: png
encryption_cipher_text: 
encryption_applied: 0
encryption_blob_encrypted: 0
size: 427522
is_shared: 0
share_id: 
master_key_id: 
type_: 4