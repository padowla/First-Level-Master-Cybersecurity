cf4674c9a4c13ce4aa1be1500ec2a29d.png

id: 4b9c55fb8c74442db7abdfa11e8cbc1a
mime: image/png
filename: 
created_time: 2023-10-07T09:32:31.757Z
updated_time: 2023-10-07T09:32:31.757Z
user_created_time: 2023-10-07T09:32:31.757Z
user_updated_time: 2023-10-07T09:32:31.757Z
file_extension: png
encryption_cipher_text: 
encryption_applied: 0
encryption_blob_encrypted: 0
size: 167608
is_shared: 0
share_id: 
master_key_id: 
user_data: 
blob_updated_time: 1696671151757
type_: 4