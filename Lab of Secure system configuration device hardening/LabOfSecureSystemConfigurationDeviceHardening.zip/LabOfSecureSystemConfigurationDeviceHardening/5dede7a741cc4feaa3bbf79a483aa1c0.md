5292300d20d21ad9bf89de894df6983e.png

id: 5dede7a741cc4feaa3bbf79a483aa1c0
mime: image/png
filename: 
created_time: 2023-09-16T09:12:03.884Z
updated_time: 2023-09-16T09:12:03.884Z
user_created_time: 2023-09-16T09:12:03.884Z
user_updated_time: 2023-09-16T09:12:03.884Z
file_extension: png
encryption_cipher_text: 
encryption_applied: 0
encryption_blob_encrypted: 0
size: 131395
is_shared: 0
share_id: 
master_key_id: 
user_data: 
blob_updated_time: 1694855523884
type_: 4