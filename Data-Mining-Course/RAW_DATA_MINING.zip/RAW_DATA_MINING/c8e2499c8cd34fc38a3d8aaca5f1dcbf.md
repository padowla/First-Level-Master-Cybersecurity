72242d00304aeec31869c815ffec7c06.png

id: c8e2499c8cd34fc38a3d8aaca5f1dcbf
mime: image/png
filename: 
created_time: 2023-03-16T10:07:55.459Z
updated_time: 2023-03-16T10:07:55.459Z
user_created_time: 2023-03-16T10:07:55.459Z
user_updated_time: 2023-03-16T10:07:55.459Z
file_extension: png
encryption_cipher_text: 
encryption_applied: 0
encryption_blob_encrypted: 0
size: 46364
is_shared: 0
share_id: 
master_key_id: 
type_: 4