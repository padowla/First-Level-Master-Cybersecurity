853e2f9cf032d941758990e1501b9e23.png

id: bc6fb3a0cbaf4bb8afff8c2475879b5f
mime: image/png
filename: 
created_time: 2023-03-03T13:58:25.372Z
updated_time: 2023-03-03T13:58:25.372Z
user_created_time: 2023-03-03T13:58:25.372Z
user_updated_time: 2023-03-03T13:58:25.372Z
file_extension: png
encryption_cipher_text: 
encryption_applied: 0
encryption_blob_encrypted: 0
size: 74378
is_shared: 0
share_id: 
master_key_id: 
type_: 4