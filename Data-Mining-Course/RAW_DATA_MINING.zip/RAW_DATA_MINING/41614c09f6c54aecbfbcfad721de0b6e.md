55939022b42b26e72268da90b75230a9.png

id: 41614c09f6c54aecbfbcfad721de0b6e
mime: image/png
filename: 
created_time: 2023-02-11T09:30:31.553Z
updated_time: 2023-02-11T09:30:31.553Z
user_created_time: 2023-02-11T09:30:31.553Z
user_updated_time: 2023-02-11T09:30:31.553Z
file_extension: png
encryption_cipher_text: 
encryption_applied: 0
encryption_blob_encrypted: 0
size: 150632
is_shared: 0
share_id: 
master_key_id: 
type_: 4