c8f24dcba7f255f11c49782e18ca34b9.png

id: bb98ff8af22247baaee06d3a7fd0a7b7
mime: image/png
filename: 
created_time: 2023-04-15T10:16:24.966Z
updated_time: 2023-04-15T10:16:24.966Z
user_created_time: 2023-04-15T10:16:24.966Z
user_updated_time: 2023-04-15T10:16:24.966Z
file_extension: png
encryption_cipher_text: 
encryption_applied: 0
encryption_blob_encrypted: 0
size: 177431
is_shared: 0
share_id: 
master_key_id: 
type_: 4