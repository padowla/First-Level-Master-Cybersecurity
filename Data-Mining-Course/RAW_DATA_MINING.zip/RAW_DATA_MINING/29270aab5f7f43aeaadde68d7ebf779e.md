e9596e531d9ab41254da9fa68d941f55.png

id: 29270aab5f7f43aeaadde68d7ebf779e
mime: image/png
filename: 
created_time: 2023-04-15T09:07:39.819Z
updated_time: 2023-04-15T09:07:39.819Z
user_created_time: 2023-04-15T09:07:39.819Z
user_updated_time: 2023-04-15T09:07:39.819Z
file_extension: png
encryption_cipher_text: 
encryption_applied: 0
encryption_blob_encrypted: 0
size: 222732
is_shared: 0
share_id: 
master_key_id: 
type_: 4