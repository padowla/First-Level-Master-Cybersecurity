e8b8dc89060c7d0e362379631cf0de85.png

id: 2861a9ace4d443cfbacc1f5d4da77c8b
mime: image/png
filename: 
created_time: 2023-03-18T09:02:48.667Z
updated_time: 2023-03-18T09:02:48.667Z
user_created_time: 2023-03-18T09:02:48.667Z
user_updated_time: 2023-03-18T09:02:48.667Z
file_extension: png
encryption_cipher_text: 
encryption_applied: 0
encryption_blob_encrypted: 0
size: 53498
is_shared: 0
share_id: 
master_key_id: 
type_: 4