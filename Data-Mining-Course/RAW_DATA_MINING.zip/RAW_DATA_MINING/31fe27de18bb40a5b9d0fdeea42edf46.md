45893a5af8175e7f9aeff6bff3990609.png

id: 31fe27de18bb40a5b9d0fdeea42edf46
mime: image/png
filename: 
created_time: 2023-02-18T09:15:48.753Z
updated_time: 2023-02-18T09:15:48.753Z
user_created_time: 2023-02-18T09:15:48.753Z
user_updated_time: 2023-02-18T09:15:48.753Z
file_extension: png
encryption_cipher_text: 
encryption_applied: 0
encryption_blob_encrypted: 0
size: 229864
is_shared: 0
share_id: 
master_key_id: 
type_: 4