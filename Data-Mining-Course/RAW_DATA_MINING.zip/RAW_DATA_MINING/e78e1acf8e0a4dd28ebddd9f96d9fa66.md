bae8290e2c552e3e78411416d825d44e.png

id: e78e1acf8e0a4dd28ebddd9f96d9fa66
mime: image/png
filename: 
created_time: 2023-03-23T09:34:24.707Z
updated_time: 2023-03-23T09:34:24.707Z
user_created_time: 2023-03-23T09:34:24.707Z
user_updated_time: 2023-03-23T09:34:24.707Z
file_extension: png
encryption_cipher_text: 
encryption_applied: 0
encryption_blob_encrypted: 0
size: 51250
is_shared: 0
share_id: 
master_key_id: 
type_: 4