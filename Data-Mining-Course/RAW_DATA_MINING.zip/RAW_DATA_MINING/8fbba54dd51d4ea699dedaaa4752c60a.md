7108efa31d3735d9ac2fde8d3d5aa7a0.png

id: 8fbba54dd51d4ea699dedaaa4752c60a
mime: image/png
filename: 
created_time: 2023-02-13T23:06:53.908Z
updated_time: 2023-02-13T23:06:53.908Z
user_created_time: 2023-02-13T23:06:53.908Z
user_updated_time: 2023-02-13T23:06:53.908Z
file_extension: png
encryption_cipher_text: 
encryption_applied: 0
encryption_blob_encrypted: 0
size: 89705
is_shared: 0
share_id: 
master_key_id: 
type_: 4