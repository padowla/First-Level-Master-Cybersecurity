197f10e4e15e77bed56e1244511ee6e6.png

id: 7ad1327e64d94afebaa8dac5e9dab681
mime: image/png
filename: 
created_time: 2023-04-15T10:57:08.243Z
updated_time: 2023-04-15T10:57:08.243Z
user_created_time: 2023-04-15T10:57:08.243Z
user_updated_time: 2023-04-15T10:57:08.243Z
file_extension: png
encryption_cipher_text: 
encryption_applied: 0
encryption_blob_encrypted: 0
size: 122653
is_shared: 0
share_id: 
master_key_id: 
type_: 4