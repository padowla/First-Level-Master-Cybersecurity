8f146faa4fd37cb46ac4136ae1c65820.png

id: 667d010e0d0042dd9bffdd6a35ccfaab
mime: image/png
filename: 
created_time: 2023-02-18T10:43:52.046Z
updated_time: 2023-02-18T10:43:52.046Z
user_created_time: 2023-02-18T10:43:52.046Z
user_updated_time: 2023-02-18T10:43:52.046Z
file_extension: png
encryption_cipher_text: 
encryption_applied: 0
encryption_blob_encrypted: 0
size: 214841
is_shared: 0
share_id: 
master_key_id: 
type_: 4