3e04c9fb17c03dc6958d265fcc4ef86a.png

id: f3c9ecdadb244fceafb54d7a254437fe
mime: image/png
filename: 
created_time: 2023-02-18T09:38:37.569Z
updated_time: 2023-02-18T09:38:37.569Z
user_created_time: 2023-02-18T09:38:37.569Z
user_updated_time: 2023-02-18T09:38:37.569Z
file_extension: png
encryption_cipher_text: 
encryption_applied: 0
encryption_blob_encrypted: 0
size: 178304
is_shared: 0
share_id: 
master_key_id: 
type_: 4