17065ad6929a2b62970685463d49f1ac.png

id: ea434ab3f5ba44ecbdbddd3c5f4f5bd5
mime: image/png
filename: 
created_time: 2023-03-07T15:11:54.429Z
updated_time: 2023-03-07T15:11:54.429Z
user_created_time: 2023-03-07T15:11:54.429Z
user_updated_time: 2023-03-07T15:11:54.429Z
file_extension: png
encryption_cipher_text: 
encryption_applied: 0
encryption_blob_encrypted: 0
size: 116457
is_shared: 0
share_id: 
master_key_id: 
type_: 4