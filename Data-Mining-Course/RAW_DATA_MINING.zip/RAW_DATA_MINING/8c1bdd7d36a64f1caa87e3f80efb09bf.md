2d47b63442408c66b6827c68dd4300ae.png

id: 8c1bdd7d36a64f1caa87e3f80efb09bf
mime: image/png
filename: 
created_time: 2023-02-11T10:39:12.311Z
updated_time: 2023-02-11T10:39:12.311Z
user_created_time: 2023-02-11T10:39:12.311Z
user_updated_time: 2023-02-11T10:39:12.311Z
file_extension: png
encryption_cipher_text: 
encryption_applied: 0
encryption_blob_encrypted: 0
size: 123840
is_shared: 0
share_id: 
master_key_id: 
type_: 4