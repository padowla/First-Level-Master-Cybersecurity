a27c63f0b98c36a0182e61772cba4413.png

id: 498c1d0be0334fa2ac2abb6b1cb8e0eb
mime: image/png
filename: 
created_time: 2023-04-01T10:52:03.220Z
updated_time: 2023-04-01T10:52:03.220Z
user_created_time: 2023-04-01T10:52:03.220Z
user_updated_time: 2023-04-01T10:52:03.220Z
file_extension: png
encryption_cipher_text: 
encryption_applied: 0
encryption_blob_encrypted: 0
size: 123831
is_shared: 0
share_id: 
master_key_id: 
type_: 4