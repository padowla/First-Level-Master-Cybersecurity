409426383b0b0c39c5455cc3c386d92c.png

id: 23bc81f4c67c4cfeab0bcbb3416de46a
mime: image/png
filename: 
created_time: 2023-03-31T11:06:10.642Z
updated_time: 2023-03-31T11:06:10.642Z
user_created_time: 2023-03-31T11:06:10.642Z
user_updated_time: 2023-03-31T11:06:10.642Z
file_extension: png
encryption_cipher_text: 
encryption_applied: 0
encryption_blob_encrypted: 0
size: 158026
is_shared: 0
share_id: 
master_key_id: 
type_: 4