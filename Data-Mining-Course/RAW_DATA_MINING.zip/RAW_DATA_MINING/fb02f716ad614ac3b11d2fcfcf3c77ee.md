cf8fcd220bb9ddf0b0570d97b33fa679.png

id: fb02f716ad614ac3b11d2fcfcf3c77ee
mime: image/png
filename: 
created_time: 2023-04-15T10:19:23.213Z
updated_time: 2023-04-15T10:19:23.213Z
user_created_time: 2023-04-15T10:19:23.213Z
user_updated_time: 2023-04-15T10:19:23.213Z
file_extension: png
encryption_cipher_text: 
encryption_applied: 0
encryption_blob_encrypted: 0
size: 261199
is_shared: 0
share_id: 
master_key_id: 
type_: 4