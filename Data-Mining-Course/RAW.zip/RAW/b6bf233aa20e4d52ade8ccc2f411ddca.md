645e47e6e0816056fb69114254c38e8a.png

id: b6bf233aa20e4d52ade8ccc2f411ddca
mime: image/png
filename: 
created_time: 2023-03-18T08:34:21.190Z
updated_time: 2023-03-18T08:34:21.190Z
user_created_time: 2023-03-18T08:34:21.190Z
user_updated_time: 2023-03-18T08:34:21.190Z
file_extension: png
encryption_cipher_text: 
encryption_applied: 0
encryption_blob_encrypted: 0
size: 136450
is_shared: 0
share_id: 
master_key_id: 
type_: 4