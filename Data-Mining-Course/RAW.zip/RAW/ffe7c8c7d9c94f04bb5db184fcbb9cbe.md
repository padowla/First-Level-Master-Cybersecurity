df8f9cac5f30fd1780e6a90f9e02279b.png

id: ffe7c8c7d9c94f04bb5db184fcbb9cbe
mime: image/png
filename: 
created_time: 2023-02-11T10:48:23.487Z
updated_time: 2023-02-11T10:48:23.487Z
user_created_time: 2023-02-11T10:48:23.487Z
user_updated_time: 2023-02-11T10:48:23.487Z
file_extension: png
encryption_cipher_text: 
encryption_applied: 0
encryption_blob_encrypted: 0
size: 170832
is_shared: 0
share_id: 
master_key_id: 
type_: 4