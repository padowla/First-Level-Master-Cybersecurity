5d340dba8419b40ea8c618a76b706dfd.png

id: ddc0edae0fa84b598f6cecbf7995b6b3
mime: image/png
filename: 
created_time: 2023-03-16T10:07:07.339Z
updated_time: 2023-03-16T10:07:07.339Z
user_created_time: 2023-03-16T10:07:07.339Z
user_updated_time: 2023-03-16T10:07:07.339Z
file_extension: png
encryption_cipher_text: 
encryption_applied: 0
encryption_blob_encrypted: 0
size: 154543
is_shared: 0
share_id: 
master_key_id: 
type_: 4