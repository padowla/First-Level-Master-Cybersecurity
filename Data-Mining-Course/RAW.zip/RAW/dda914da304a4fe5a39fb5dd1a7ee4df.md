10432a5138dbed9f82020cb0789ca42a.png

id: dda914da304a4fe5a39fb5dd1a7ee4df
mime: image/png
filename: 
created_time: 2023-02-10T14:34:59.312Z
updated_time: 2023-02-10T14:34:59.312Z
user_created_time: 2023-02-10T14:34:59.312Z
user_updated_time: 2023-02-10T14:34:59.312Z
file_extension: png
encryption_cipher_text: 
encryption_applied: 0
encryption_blob_encrypted: 0
size: 82987
is_shared: 0
share_id: 
master_key_id: 
type_: 4