275a9bf468f279f69c76570147ee44f7.png

id: 9d8ad897effc4b08ac105db4f5aaea7d
mime: image/png
filename: 
created_time: 2023-02-15T16:20:05.579Z
updated_time: 2023-02-15T16:20:05.579Z
user_created_time: 2023-02-15T16:20:05.579Z
user_updated_time: 2023-02-15T16:20:05.579Z
file_extension: png
encryption_cipher_text: 
encryption_applied: 0
encryption_blob_encrypted: 0
size: 67131
is_shared: 0
share_id: 
master_key_id: 
type_: 4