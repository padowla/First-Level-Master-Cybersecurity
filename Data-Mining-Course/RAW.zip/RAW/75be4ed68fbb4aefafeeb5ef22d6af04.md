a35245a9a92cc44226fda222c5c7b583.png

id: 75be4ed68fbb4aefafeeb5ef22d6af04
mime: image/png
filename: 
created_time: 2023-02-11T10:42:48.612Z
updated_time: 2023-02-11T10:42:48.612Z
user_created_time: 2023-02-11T10:42:48.612Z
user_updated_time: 2023-02-11T10:42:48.612Z
file_extension: png
encryption_cipher_text: 
encryption_applied: 0
encryption_blob_encrypted: 0
size: 114300
is_shared: 0
share_id: 
master_key_id: 
type_: 4