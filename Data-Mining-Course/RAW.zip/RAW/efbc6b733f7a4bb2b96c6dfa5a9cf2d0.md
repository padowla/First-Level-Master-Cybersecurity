a4a4374c8243e52541adaf3b575e8746.png

id: efbc6b733f7a4bb2b96c6dfa5a9cf2d0
mime: image/png
filename: 
created_time: 2023-02-04T12:24:47.220Z
updated_time: 2023-02-04T12:24:47.220Z
user_created_time: 2023-02-04T12:24:47.220Z
user_updated_time: 2023-02-04T12:24:47.220Z
file_extension: png
encryption_cipher_text: 
encryption_applied: 0
encryption_blob_encrypted: 0
size: 105630
is_shared: 0
share_id: 
master_key_id: 
type_: 4