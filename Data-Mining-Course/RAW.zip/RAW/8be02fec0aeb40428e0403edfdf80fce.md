62d06d293af11a330f4ee3f02454a153.png

id: 8be02fec0aeb40428e0403edfdf80fce
mime: image/png
filename: 
created_time: 2023-03-03T14:43:31.845Z
updated_time: 2023-03-03T14:43:31.845Z
user_created_time: 2023-03-03T14:43:31.845Z
user_updated_time: 2023-03-03T14:43:31.845Z
file_extension: png
encryption_cipher_text: 
encryption_applied: 0
encryption_blob_encrypted: 0
size: 49224
is_shared: 0
share_id: 
master_key_id: 
type_: 4