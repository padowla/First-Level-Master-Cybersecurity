57fdb95942e1ebd11b64e966bc919a8e.png

id: ad1ee519d8454adbbc0068abbf8ac8e1
mime: image/png
filename: 
created_time: 2023-03-17T13:49:32.557Z
updated_time: 2023-03-17T13:49:32.557Z
user_created_time: 2023-03-17T13:49:32.557Z
user_updated_time: 2023-03-17T13:49:32.557Z
file_extension: png
encryption_cipher_text: 
encryption_applied: 0
encryption_blob_encrypted: 0
size: 157956
is_shared: 0
share_id: 
master_key_id: 
type_: 4