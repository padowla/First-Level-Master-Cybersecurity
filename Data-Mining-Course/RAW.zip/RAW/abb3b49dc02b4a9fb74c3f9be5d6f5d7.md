766ce817092f114f0e7857f1eda97a8b.png

id: abb3b49dc02b4a9fb74c3f9be5d6f5d7
mime: image/png
filename: 
created_time: 2023-02-10T14:44:06.253Z
updated_time: 2023-02-10T14:44:06.253Z
user_created_time: 2023-02-10T14:44:06.253Z
user_updated_time: 2023-02-10T14:44:06.253Z
file_extension: png
encryption_cipher_text: 
encryption_applied: 0
encryption_blob_encrypted: 0
size: 59017
is_shared: 0
share_id: 
master_key_id: 
type_: 4